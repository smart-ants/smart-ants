$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.Windows.Forms.Application]::EnableVisualStyles()

$expected = '__PACKAGE_SHA256__'
$all = [IO.File]::ReadAllText($env:SAQ_BOOTSTRAP, [Text.Encoding]::UTF8)
$encoded = ([regex]::Split($all, '(?m)^#__SAQ_PAYLOAD__\r?$'))[1] -replace '\s', ''
$package = [Convert]::FromBase64String($encoded)
$hasher = [Security.Cryptography.SHA256]::Create()
$actual = [BitConverter]::ToString($hasher.ComputeHash($package)).Replace('-','').ToLowerInvariant()
if ($actual -ne $expected) { throw 'PACKAGE_HASH_MISMATCH' }
$cache = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SMART_ANT_QUANTUM\API_INSTALLER'
[IO.Directory]::CreateDirectory($cache) | Out-Null
$settingsFile = Join-Path $cache 'bootstrap_settings.json'
$script:download = 'C:\SAQ_AUDIT\DOWNLOADS'
if (Test-Path -LiteralPath $settingsFile -PathType Leaf) {
    try {
        $saved = Get-Content -LiteralPath $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($saved.download_directory -and [IO.Path]::IsPathRooted([string]$saved.download_directory)) {
            $script:download = [string]$saved.download_directory
        }
    } catch { }
}
$script:zipPath = $null
$form = New-Object System.Windows.Forms.Form
$form.Text = '루카스 · 자동 저장 / 자동 압축 해제'
$form.Size = New-Object System.Drawing.Size(780,420)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Malgun Gothic',10)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$title = New-Object System.Windows.Forms.Label
$title.Text = '자동 저장 · 자동 압축 해제 · 실행 준비'
$title.Font = New-Object System.Drawing.Font('Malgun Gothic',17,[Drawing.FontStyle]::Bold)
$title.SetBounds(22,20,720,38)
$form.Controls.Add($title)
$note = New-Object System.Windows.Forms.Label
$note.Text = '내장 패키지 SHA-256 확인 → 자동 폴더 생성·저장 → 폴더 열기 → 자동 압축 해제'
$note.SetBounds(24,68,710,45)
$form.Controls.Add($note)
$path = New-Object System.Windows.Forms.TextBox
$path.ReadOnly = $true
$path.SetBounds(24,122,555,30)
$form.Controls.Add($path)
$choose = New-Object System.Windows.Forms.Button
$choose.Text = '저장 폴더 변경'
$choose.SetBounds(590,120,145,34)
$form.Controls.Add($choose)
$status = New-Object System.Windows.Forms.Label
$status.SetBounds(24,175,710,68)
$form.Controls.Add($status)
$extract = New-Object System.Windows.Forms.Button
$extract.Text = '자동 압축 해제 재시도 · 실행 화면 열기'
$extract.Font = New-Object System.Drawing.Font('Malgun Gothic',12,[Drawing.FontStyle]::Bold)
$extract.SetBounds(24,260,535,58)
$extract.Enabled = $false
$form.Controls.Add($extract)
$close = New-Object System.Windows.Forms.Button
$close.Text = '지금은 여기까지'
$close.SetBounds(575,260,160,58)
$close.Add_Click({ $form.Close() })
$form.Controls.Add($close)
$scope = New-Object System.Windows.Forms.Label
$scope.Text = '압축 해제까지 자동 진행합니다. 실제 코드 적용은 다음 화면의 1번 PASS → 2번 클릭 후입니다.'
$scope.SetBounds(24,335,710,40)
$form.Controls.Add($scope)

function Prepare-Package {
    $extract.Enabled = $false
    $script:zipPath = $null
    $path.Text = $script:download
    try {
        if ([IO.Path]::GetFullPath($script:download) -match '(?i)(^|[\\/])V7_STAGE10_DIRECT_CHART([\\/]|$)') {
            throw 'OPERATING_STAGE10_DOWNLOAD_PATH_FORBIDDEN'
        }
        [IO.Directory]::CreateDirectory($script:download) | Out-Null
        $filename = 'SAQ_API_INSTALLER_' + $expected.Substring(0,12) + '.zip'
        $candidate = Join-Path $script:download $filename
        if (Test-Path -LiteralPath $candidate) {
            $existing = (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($existing -ne $expected) {
                $candidate = Join-Path $script:download ('SAQ_API_INSTALLER_' + [guid]::NewGuid().ToString('N') + '.zip')
            }
        }
        if (-not (Test-Path -LiteralPath $candidate)) {
            $output = [IO.File]::Open($candidate,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
            try { $output.Write($package,0,$package.Length); $output.Flush($true) } finally { $output.Dispose() }
        }
        if ((Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) {
            throw 'SAVED_PACKAGE_HASH_MISMATCH'
        }
        $script:zipPath = $candidate
        @{version=1;download_directory=$script:download} | ConvertTo-Json | Set-Content -LiteralPath $settingsFile -Encoding UTF8
        $status.Text = "준비 완료. 지정 폴더에 저장하고 해시를 확인했습니다.`r`n자동 압축 해제 후 실행 화면을 엽니다."
        $status.ForeColor = [Drawing.Color]::DarkGreen
        $extract.Enabled = $true
        Start-Process -FilePath explorer.exe -ArgumentList ('/select,"' + $candidate + '"') | Out-Null
    } catch {
        $status.Text = 'STOP — 지정 폴더 저장 실패. 폴더 변경 버튼으로 쓸 수 있는 위치를 선택하세요. (' + $_.Exception.GetType().Name + ')'
        $status.ForeColor = [Drawing.Color]::Firebrick
    }
}

$choose.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = '다음 실행에도 사용할 패키지 자동 저장 폴더'
    $dialog.SelectedPath = $script:download
    if ($dialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) {
        $script:download = $dialog.SelectedPath
        Prepare-Package
        if ($script:zipPath -and $extract.Enabled) { $extract.PerformClick() }
    }
})

$extract.Add_Click({
    $extract.Enabled = $false
    try {
        if ((Get-FileHash -LiteralPath $script:zipPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) {
            throw 'PACKAGE_CHANGED'
        }
        $work = Join-Path $script:download ('SAQ_SETUP_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0,8))
        [IO.Directory]::CreateDirectory($work) | Out-Null
        $zip = [IO.Compression.ZipFile]::OpenRead($script:zipPath)
        try {
            $seen = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
            $total = 0
            foreach ($entry in $zip.Entries) {
                $name = $entry.FullName.Replace('\','/')
                if ($name.StartsWith('/') -or $name.Contains(':') -or $name -match '(^|/)\.\.(/|$)' -or -not $seen.Add($name)) {
                    throw 'UNSAFE_ARCHIVE_PATH'
                }
                $full = [IO.Path]::GetFullPath((Join-Path $work $entry.FullName))
                if (-not $full.StartsWith(([IO.Path]::GetFullPath($work) + '\'), [StringComparison]::OrdinalIgnoreCase)) {
                    throw 'ARCHIVE_PATH_ESCAPES'
                }
                if (($entry.ExternalAttributes -shr 16 -band 61440) -eq 40960) { throw 'ARCHIVE_LINK_REJECTED' }
                $total += $entry.Length
                if ($total -gt 268435456 -or $zip.Entries.Count -gt 1000) { throw 'ARCHIVE_SIZE_LIMIT' }
            }
        } finally { $zip.Dispose() }
        [IO.Compression.ZipFile]::ExtractToDirectory($script:zipPath,$work)
        $runner = Join-Path $work 'SAQ_INSTALLER\RUN_INSTALLER.cmd'
        if (-not (Test-Path -LiteralPath $runner -PathType Leaf)) { throw 'RUNNER_NOT_FOUND' }
        $status.Text = '압축 해제 완료. 독립 API 검사/백업/적용 화면을 엽니다.'
        Start-Process -FilePath $runner -WorkingDirectory (Split-Path $runner) | Out-Null
        $form.Close()
    } catch {
        $status.Text = 'STOP — 압축 해제/실행 준비 실패. 운영 파일은 변경하지 않았습니다. (' + $_.Exception.GetType().Name + ')'
        $status.ForeColor = [Drawing.Color]::Firebrick
        $extract.Enabled = [bool]$script:zipPath
    }
})
$form.Add_Shown({
    Prepare-Package
    if ($script:zipPath -and $extract.Enabled) { $extract.PerformClick() }
})
[void]$form.ShowDialog()
