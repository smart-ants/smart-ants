"""Numbered, gated local installation UI. No unattended application/DB activation."""

from __future__ import annotations

from datetime import datetime
import json
import os
from pathlib import Path
import queue
import sys
import threading
import uuid
import webbrowser

from saq_installer.core import BackendRunner, Installer, Spec
from saq_installer.organizer import (
    Organizer,
    default_roots,
    download_directory,
    save_download_directory,
)

ROOT = Path(__file__).resolve().parents[1]

MESSAGES = {
    "NEW": "1번 검사를 실행하세요. 운영 소스·DB 변경은 없습니다.",
    "CHECKING": "독립 환경 준비 및 전체 검사 중… PASS 전에는 적용할 수 없습니다.",
    "PASS": "PASS — 검사가 통과했습니다. 2번 버튼으로 자동 백업 후 코드를 적용합니다.",
    "STOP": "STOP — 적용하지 않았습니다. 원인·로그 버튼을 확인하세요.",
    "APPLYING": "자동 백업 → 백업 해시 확인 → 코드 적용 → 적용 파일 확인 중…",
    "SUCCESS": "성공 — 독립 API 코드 적용 완료. 3번 결과물 확인을 누르세요. 운영 DB는 변경하지 않았습니다.",
    "FAILED_UNCHANGED": "실패 — 기존 상태는 변경되지 않았습니다. 백업·원인 기록을 확인하세요.",
    "FAILED_ROLLED_BACK": "실패 — 기존 파일로 자동 원복했고 원본 상태를 검증했습니다.",
    "FAILED_RECOVERY_REQUIRED": "복구 확인 필요 — 자동 원복을 완료하지 못했습니다. 백업/보존본을 유지했습니다.",
}


def main() -> int:
    if sys.version_info < (3, 11):
        raise RuntimeError("Python 3.11+ required")
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from tkinter.scrolledtext import ScrolledText

    metadata = json.loads((ROOT / "release.json").read_text(encoding="utf-8"))
    spec = Spec(
        metadata["payload_sha256"],
        tuple(metadata["accepted_manifest_hashes"]),
        tuple(metadata["accepted_payload_hashes"]),
    )
    cache_root = (
        Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local/share")))
        / "SMART_ANT_QUANTUM"
        / "API_INSTALLER"
    )
    cache_root.mkdir(parents=True, exist_ok=True)
    window = tk.Tk()
    window.title("루카스 · SAQ 검사 / 백업 / 적용")
    window.geometry("930x825")
    window.minsize(780, 650)
    style = ttk.Style(window)
    if "clam" in style.theme_names():
        style.theme_use("clam")
    style.configure("TButton", font=("Malgun Gothic", 11), padding=9)
    style.configure("Action.TButton", font=("Malgun Gothic", 13, "bold"), padding=15)
    body = ttk.Frame(window, padding=22)
    body.pack(fill="both", expand=True)
    ttk.Label(
        body, text="SAQ 독립 수급 API · 단계별 자동 실행", font=("Malgun Gothic", 20, "bold")
    ).pack(anchor="w")
    ttk.Label(
        body, text="1 검사 → PASS일 때 2 적용 → 성공 시 3 결과 확인", font=("Malgun Gothic", 12)
    ).pack(anchor="w", pady=(8, 4))
    ttk.Label(
        body,
        text="적용 전 자동 백업 / 실패 시 자동 원복 / 기존 Stage10·운영 DB·키·차트 변경 없음",
        wraplength=850,
    ).pack(anchor="w", pady=(0, 14))
    target = tk.StringVar(value=r"C:\SAQ_DEV\SAQ_INVESTOR_FLOW_API_MANAGED")
    row = ttk.Frame(body)
    row.pack(fill="x")
    ttk.Label(row, text="독립 API 대상").pack(side="left", padx=(0, 10))
    target_entry = ttk.Entry(row, textvariable=target)
    target_entry.pack(side="left", fill="x", expand=True)
    events: queue.Queue[tuple[str, str]] = queue.Queue()
    state: dict[str, object] = {
        "engine": None,
        "busy": False,
        "organizing": False,
        "organization": None,
    }

    def select_parent() -> None:
        selected = filedialog.askdirectory(
            title="설치할 상위 폴더 선택 — 기존 V7 폴더는 선택하지 마세요"
        )
        if selected:
            target.set(str(Path(selected) / "SAQ_INVESTOR_FLOW_API_MANAGED"))

    choose = ttk.Button(row, text="상위 폴더 선택", command=select_parent)
    choose.pack(side="left", padx=(8, 0))
    download_text = tk.StringVar(value="자동 저장 / ZIP 모음: " + str(download_directory()))
    ttk.Label(body, textvariable=download_text, wraplength=850).pack(anchor="w", pady=(8, 0))
    zip_row = ttk.Frame(body)
    zip_row.pack(fill="x", pady=(5, 0))
    zip_open = ttk.Button(
        zip_row, text="ZIP 모음 폴더 열기", command=lambda: open_path(download_directory())
    )
    zip_open.pack(side="left")

    def choose_download() -> None:
        chosen = filedialog.askdirectory(title="앞으로 사용할 자동 저장·ZIP 모음 폴더")
        if chosen:
            try:
                save_download_directory(Path(chosen))
                download_text.set("자동 저장 / ZIP 모음: " + str(download_directory()))
                organize()
            except Exception as exc:
                messagebox.showerror(
                    "STOP", "저장 폴더를 변경하지 못했습니다: " + type(exc).__name__
                )

    zip_choose = ttk.Button(zip_row, text="저장 폴더 변경·기억", command=choose_download)
    zip_choose.pack(side="left", padx=8)
    label = tk.StringVar(value=MESSAGES["NEW"])
    status = ttk.Label(body, textvariable=label, font=("Malgun Gothic", 12, "bold"), wraplength=850)
    status.pack(anchor="w", pady=(17, 10))
    actions = ttk.Frame(body)
    actions.pack(fill="x")

    def log(text: str) -> None:
        console.configure(state="normal")
        console.insert("end", text + "\n")
        console.see("end")
        console.configure(state="disabled")

    def refresh() -> None:
        engine = state["engine"]
        phase = engine.state if isinstance(engine, Installer) else "NEW"
        label.set(
            "흩어진 SAQ ZIP을 자동 검색·검증·이동 중…"
            if state["organizing"]
            else MESSAGES.get(phase, phase)
        )
        check_button.configure(state="disabled" if state["busy"] else "normal")
        apply_button.configure(
            state="normal" if phase == "PASS" and not state["busy"] else "disabled"
        )
        results_button.configure(
            state="normal" if phase == "SUCCESS" and not state["busy"] else "disabled"
        )
        for widget in (target_entry, choose, zip_choose):
            widget.configure(state="disabled" if state["busy"] else "normal")
        report_button.configure(
            state=(
                "normal"
                if isinstance(engine, Installer) and (engine.cache / "RESULT.html").exists()
                else "disabled"
            )
        )
        backup_button.configure(
            state=(
                "normal"
                if isinstance(engine, Installer) and engine.result.get("backup")
                else "disabled"
            )
        )
        if phase in ("PASS", "SUCCESS"):
            status.configure(foreground="#08754c")
        elif phase in (
            "STOP",
            "FAILED_UNCHANGED",
            "FAILED_ROLLED_BACK",
            "FAILED_RECOVERY_REQUIRED",
        ):
            status.configure(foreground="#b12d32")
        else:
            status.configure(foreground="#163e65")

    def perform(action: str) -> None:
        if state["busy"]:
            return
        if action == "check":
            run = cache_root / (datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:8])
            try:
                state["engine"] = Installer(
                    ROOT / "backend_payload.zip",
                    spec,
                    Path(target.get()),
                    run,
                    BackendRunner(constraints=ROOT / "constraints.txt"),
                    log=lambda text: events.put(("log", text)),
                )
            except Exception as exc:
                messagebox.showerror(
                    "STOP", "검사 환경을 준비하지 못했습니다: " + type(exc).__name__
                )
                return
        engine = state["engine"]
        if not isinstance(engine, Installer):
            return
        state["busy"] = True
        progress.start(12)
        # Change only the display until the worker enters the guarded core.
        check_button.configure(state="disabled")
        apply_button.configure(state="disabled")
        results_button.configure(state="disabled")
        target_entry.configure(state="disabled")
        choose.configure(state="disabled")
        zip_choose.configure(state="disabled")
        label.set(MESSAGES["CHECKING" if action == "check" else "APPLYING"])

        def worker() -> None:
            try:
                if action == "check":
                    engine.check()
                else:
                    engine.apply()
            except Exception as exc:
                engine.state = "FAILED_RECOVERY_REQUIRED" if action == "apply" else "STOP"
                try:
                    engine.write_result(reason=type(exc).__name__)
                except Exception:
                    pass
            events.put(("done", engine.state))

        threading.Thread(target=worker, daemon=True).start()

    def organize() -> None:
        if state["busy"]:
            return
        state.update(busy=True, organizing=True)
        progress.start(12)
        refresh()
        installed_target = Path(target.get())

        def worker() -> None:
            try:
                destination = download_directory()
                manager = Organizer(
                    destination,
                    default_roots(),
                    [ROOT, cache_root, installed_target],
                    log=lambda text: events.put(("log", text)),
                )
                result = manager.run()
                state["organization"] = result
                events.put(("organized", str(result["moved"])))
            except Exception as exc:
                events.put(("organize_error", type(exc).__name__))

        threading.Thread(target=worker, daemon=True).start()

    def open_path(path: Path) -> None:
        if os.name == "nt":
            os.startfile(str(path))
        else:
            webbrowser.open(path.as_uri())

    def open_report() -> None:
        engine = state["engine"]
        if isinstance(engine, Installer):
            open_path(engine.cache / "RESULT.html")

    def open_backup() -> None:
        engine = state["engine"]
        if isinstance(engine, Installer) and engine.result.get("backup"):
            open_path(Path(str(engine.result["backup"])))

    def show_result() -> None:
        engine = state["engine"]
        if isinstance(engine, Installer) and engine.state == "SUCCESS":
            open_report()
            open_path(engine.target)

    check_button = ttk.Button(
        actions, text="1  실행 TEST", style="Action.TButton", command=lambda: perform("check")
    )
    check_button.pack(side="left", fill="x", expand=True)
    apply_button = ttk.Button(
        actions,
        text="2  백업 후 적용",
        style="Action.TButton",
        command=lambda: perform("apply"),
        state="disabled",
    )
    apply_button.pack(side="left", fill="x", expand=True, padx=8)
    results_button = ttk.Button(
        actions,
        text="3  결과물 확인",
        style="Action.TButton",
        command=show_result,
        state="disabled",
    )
    results_button.pack(side="left", fill="x", expand=True)
    progress = ttk.Progressbar(body, mode="indeterminate")
    progress.pack(fill="x", pady=(14, 10))
    console = ScrolledText(
        body, height=15, wrap="word", font=("Malgun Gothic", 10), state="disabled"
    )
    console.pack(fill="both", expand=True)
    secondary = ttk.Frame(body)
    secondary.pack(fill="x", pady=(10, 0))
    report_button = ttk.Button(
        secondary, text="로그·원인 보기", command=open_report, state="disabled"
    )
    report_button.pack(side="left")
    backup_button = ttk.Button(
        secondary, text="자동 백업 폴더 열기", command=open_backup, state="disabled"
    )
    backup_button.pack(side="left", padx=8)
    ttk.Label(
        body,
        text="Python 3.11+ 및 Docker 필요. 검사 시 독립 가상환경에 개발 의존성을 준비합니다.\n"
        "‘성공’은 코드 파일 적용 성공이며 운영 DB 마이그레이션·실데이터 수집 성공은 아닙니다.",
        wraplength=850,
    ).pack(anchor="w", pady=(10, 0))

    def changed(*args: object) -> None:
        if not state["busy"]:
            state["engine"] = None
            refresh()

    def poll() -> None:
        try:
            while True:
                kind, text = events.get_nowait()
                if kind == "log":
                    log(text)
                elif kind in ("organized", "organize_error"):
                    state.update(busy=False, organizing=False)
                    progress.stop()
                    refresh()
                    if kind == "organized":
                        report = state["organization"]
                        if isinstance(report, dict):
                            note = (
                                "정리 범위 검색 완료"
                                if report["complete_within_allowed_scope"]
                                else "일부 위치는 접근/시간 제한으로 미확인"
                            )
                            log(
                                f"ZIP 자동 정리: 이동 {text}개 / "
                                f"원본 유지 {report['copied_source_retained']}개. {note}"
                            )
                            log("정리 기록: " + str(report["journal"]))
                            for code, count in report["counts"].items():
                                if code not in ("COPY_VERIFIED", "MOVED", "FINISHED"):
                                    log(f"ZIP 정리 참고: {code} = {count}개")
                    else:
                        log("ZIP 정리 STOP: " + text + ". 원본을 강제로 삭제하지 않았습니다.")
                else:
                    state["busy"] = False
                    progress.stop()
                    refresh()
                    log(MESSAGES.get(text, text))
        except queue.Empty:
            pass
        window.after(120, poll)

    def close() -> None:
        if state["busy"]:
            messagebox.showinfo("진행 중", "검사 또는 백업/원복이 끝난 후 닫을 수 있습니다.")
        else:
            window.destroy()

    target.trace_add("write", changed)
    window.protocol("WM_DELETE_WINDOW", close)
    refresh()
    organize()
    poll()
    window.mainloop()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("[STOP] Installer UI could not start: " + type(exc).__name__)
        sys.exit(2)
