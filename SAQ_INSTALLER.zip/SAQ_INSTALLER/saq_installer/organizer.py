"""Local SAQ archive organization: verified copy before deleting any source."""

from __future__ import annotations

from datetime import datetime
import json
import os
from pathlib import Path
import re
import shutil
import time
from typing import Callable
import uuid
import zipfile

from saq_installer.core import atomic_json, relative, reparse, sha

BRAND = re.compile(r"^(SMART[_ -]?ANT[_ -]?QUANTUM|SAQ[_ -]|LUCAS[_ -]SAQ)", re.I)
SENSITIVE = re.compile(
    r"(^\.env($|\.)|인증|비밀|api.?keys?|password|passwd|credential|secret|token)", re.I
)
SKIP = {
    "windows",
    "windows.old",
    "program files",
    "program files (x86)",
    "programdata",
    "appdata",
    "$recycle.bin",
    "system volume information",
    "recovery",
    "perflogs",
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".cache",
    "browser_profile",
    "wpystem",
    "wpsystem",
    "saq_installer",
}


def settings_file() -> Path:
    return (
        Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local/share")))
        / "SMART_ANT_QUANTUM/API_INSTALLER/bootstrap_settings.json"
    )


def download_directory() -> Path:
    try:
        value = json.loads(settings_file().read_text(encoding="utf-8-sig"))["download_directory"]
        path = Path(value)
        if path.is_absolute():
            return path
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return Path(r"C:\SAQ_AUDIT\DOWNLOADS") if os.name == "nt" else Path.home() / "Downloads/SAQ"


def save_download_directory(path: Path) -> None:
    path = path.absolute()
    if any(part.upper() == "V7_STAGE10_DIRECT_CHART" for part in path.parts):
        raise ValueError("Operating Stage10 folder cannot be a download destination")
    path.mkdir(parents=True, exist_ok=True)
    config = settings_file()
    config.parent.mkdir(parents=True, exist_ok=True)
    previous = {}
    try:
        previous = json.loads(config.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        pass
    previous.update(version=1, download_directory=str(path))
    atomic_json(config, previous)


def recent_organization(
    destination: Path, *, now: float | None = None, max_age_seconds: int = 86400
) -> dict[str, object] | None:
    """Reuse a finished search, clearly labeled as historical; never affects TEST/PASS."""
    now = time.time() if now is None else now
    try:
        candidates = []
        for journal in (destination / ".saq_zip_moves").glob("*.json"):
            state = journal.stat()
            if not reparse(journal) and 0 <= now - state.st_mtime <= max_age_seconds:
                candidates.append((state.st_mtime, journal))
        for _, journal in sorted(candidates, reverse=True)[:20]:
            if journal.stat().st_size > 8 * 1024 * 1024:
                continue
            data = json.loads(journal.read_text(encoding="utf-8-sig"))
            counts = data.get("counts", {})
            if (
                data.get("complete_within_allowed_scope") is True
                and counts.get("FINISHED") == 1
                and type(counts.get("MOVED", 0)) is int
                and counts.get("MOVED", 0) >= 0
            ):
                return {
                    "moved": counts.get("MOVED", 0),
                    "complete_within_allowed_scope": True,
                    "historical": True,
                }
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    return None


def default_roots() -> list[Path]:
    if os.name != "nt":
        return [Path.home() / name for name in ("Downloads", "Desktop", "Documents")]
    import ctypes
    from ctypes import wintypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetLogicalDrives.restype = wintypes.DWORD
    kernel.GetDriveTypeW.argtypes = [wintypes.LPCWSTR]
    kernel.GetDriveTypeW.restype = wintypes.UINT
    mask = kernel.GetLogicalDrives()
    if not mask:
        raise ctypes.WinError(ctypes.get_last_error())
    roots = []
    for number in range(26):
        drive = chr(65 + number) + ":\\"
        if mask & (1 << number) and kernel.GetDriveTypeW(drive) == 3:
            roots.append(Path(drive))
    return roots


def protected_directory(path: Path) -> bool:
    name = path.name.lower()
    return (
        name in SKIP
        or "backup" in name
        or "백업" in name
        or name.startswith(("v7_", "saq_active_v8", "saq_investor_flow_api", "saq_setup_", ".saq_"))
    )


def copy_exclusive(source: Path, destination: Path) -> None:
    if os.name == "nt":
        # CopyFile preserves NTFS streams, including the browser security zone mark.
        import ctypes
        from ctypes import wintypes

        function = ctypes.WinDLL("kernel32", use_last_error=True).CopyFileW
        function.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.BOOL]
        function.restype = wintypes.BOOL
        if not function(str(source), str(destination), True):
            error = ctypes.get_last_error()
            if error in (80, 183):
                raise FileExistsError("Destination exists")
            raise ctypes.WinError(error)
        return
    created = False
    try:
        with destination.open("xb") as output:
            created = True
            with source.open("rb") as input_file:
                shutil.copyfileobj(input_file, output, 1024 * 1024)
            output.flush()
            os.fsync(output.fileno())
        shutil.copystat(source, destination)
    except Exception:
        if created and destination.is_file():
            destination.unlink()
        raise


def classify(path: Path) -> str:
    if SENSITIVE.search(path.name) or "backup" in path.name.lower() or "백업" in path.name:
        return "EXCLUDED_SENSITIVE_OR_BACKUP"
    branded = bool(BRAND.search(path.name))
    try:
        with zipfile.ZipFile(path) as bundle:
            infos = bundle.infolist()
            if len(infos) > 20000 or sum(row.file_size for row in infos) > 512 * 1024 * 1024:
                return "UNVERIFIED_SIZE_LIMIT" if branded else "UNRELATED"
            for row in infos:
                relative(row.filename)
                if row.flag_bits & 1:
                    return "UNVERIFIED_ENCRYPTED_ARCHIVE" if branded else "UNRELATED"
                leaf = row.filename.replace("\\", "/").rsplit("/", 1)[-1]
                if leaf == "saq_secure_keys.py":
                    continue  # Module code, not a credential store.
                if SENSITIVE.search(leaf) or leaf.lower().endswith(
                    (".db", ".sqlite", ".sqlite3", ".db3", ".dpapi")
                ):
                    return "EXCLUDED_SENSITIVE_OR_DATABASE" if branded else "UNRELATED"
            if not branded:
                for row in infos:
                    leaf = row.filename.replace("\\", "/").rsplit("/", 1)[-1]
                    if leaf == "SAQ_CODEX_MASTER_HANDOFF.md":
                        branded = True
                        break
                    if leaf == "PATCH_MANIFEST.json" and row.file_size < 512 * 1024:
                        manifest = json.loads(bundle.read(row).decode("utf-8-sig"))
                        if str(manifest.get("id", "")).upper().startswith("SAQ-"):
                            branded = True
                            break
                    if leaf == "openapi.json" and row.file_size < 2 * 1024 * 1024:
                        value = json.loads(bundle.read(row).decode("utf-8-sig"))
                        title = str(value.get("info", {}).get("title", "")).upper()
                        if "SMART ANT" in title or "SAQ" in title:
                            branded = True
                            break
            if not branded:
                return "UNRELATED"
            if bundle.testzip() is not None:
                return "UNVERIFIED_CRC"
            return "REQUIRED"
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile, RuntimeError):
        return "UNVERIFIED_ARCHIVE" if branded else "UNRELATED"


class Organizer:
    def __init__(
        self,
        destination: Path,
        roots: list[Path],
        excluded: list[Path],
        log: Callable[[str], None] = lambda text: None,
        max_seconds: int = 600,
        max_files: int = 1000000,
        after_copy: Callable[[Path, Path], None] | None = None,
    ) -> None:
        self.destination = destination.absolute()
        self.roots = roots
        self.excluded = [p.resolve() for p in (destination, *excluded)]
        self.log = log
        self.max_seconds = max_seconds
        self.max_files = max_files
        self.after_copy = after_copy
        self.records: list[dict[str, object]] = []
        self.counts: dict[str, int] = {}
        self.complete = True
        self.files_seen = 0
        self.directories_seen = 0
        self.destination.mkdir(parents=True, exist_ok=True)
        journal_dir = self.destination / ".saq_zip_moves"
        journal_dir.mkdir(exist_ok=True)
        self.journal = journal_dir / (
            datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:8] + ".json"
        )
        self.started = time.monotonic()

    def record(self, state: str, **values: object) -> None:
        self.counts[state] = self.counts.get(state, 0) + 1
        self.records.append({"state": state, **values})
        atomic_json(
            self.journal,
            {
                "complete_within_allowed_scope": self.complete,
                "counts": self.counts,
                "files_seen": self.files_seen,
                "directories_seen": self.directories_seen,
                "records": self.records,
                "policy": "No system, backup, credentials, DB, Stage10, "
                "installed API or other-user folders.",
            },
        )

    def excluded_path(self, path: Path) -> bool:
        resolved = path.resolve()
        return any(resolved.is_relative_to(base) for base in self.excluded)

    def budget(self) -> bool:
        allowed = (
            self.files_seen < self.max_files and time.monotonic() - self.started < self.max_seconds
        )
        if not allowed:
            self.complete = False
        return allowed

    def publish(self, temporary: Path, name: str, source: Path, digest: str) -> Path:
        destination = self.destination / name
        while True:
            if destination.exists():
                stem = Path(name).stem
                destination = self.destination / (
                    stem + "__" + digest[:10] + "_" + uuid.uuid4().hex[:6] + ".zip"
                )
                continue
            try:
                # A hard link is atomic and refuses to overwrite an existing file.
                os.link(temporary, destination)
                return destination
            except FileExistsError:
                continue
            except OSError:
                try:
                    copy_exclusive(temporary, destination)
                    return destination
                except FileExistsError:
                    continue

    def move(self, source: Path) -> None:
        temporary = self.destination / (".saq_copy_" + uuid.uuid4().hex + ".partial")
        destination = None
        try:
            initial = source.stat()
            digest = sha(source)
            copy_exclusive(source, temporary)
            if sha(temporary) != digest:
                raise OSError("COPY_HASH_MISMATCH")
            destination = self.publish(temporary, source.name, source, digest)
            if self.after_copy:
                self.after_copy(source, destination)
            now = source.stat()
            if (
                (initial.st_size, initial.st_mtime_ns) != (now.st_size, now.st_mtime_ns)
                or sha(source) != digest
                or sha(destination) != digest
            ):
                self.record(
                    "SOURCE_CHANGED_OR_COPY_UNVERIFIED",
                    source=str(source),
                    destination=str(destination),
                )
                return
            shutil.copystat(source, destination)
            # The verified destination and durable journal exist before unlink.
            self.record(
                "COPY_VERIFIED", source=str(source), destination=str(destination), sha256=digest
            )
            try:
                source.unlink()
            except OSError:
                self.record(
                    "COPIED_SOURCE_RETAINED",
                    source=str(source),
                    destination=str(destination),
                    sha256=digest,
                )
                return
            self.record("MOVED", source=str(source), destination=str(destination), sha256=digest)
            self.log("ZIP 이동 완료: " + destination.name)
        except Exception as exc:
            self.complete = False
            self.record("MOVE_NOT_COMPLETED", source=str(source), error_type=type(exc).__name__)
        finally:
            if temporary.exists():
                try:
                    temporary.unlink()
                except OSError:
                    self.record("TEMPORARY_COPY_RETAINED")

    def run(self) -> dict[str, object]:
        seen = set()
        for root in self.roots:
            if not root.is_dir():
                continue
            stack = [root]
            while stack:
                if not self.budget():
                    self.complete = False
                    self.record("SEARCH_LIMIT_REACHED")
                    break
                directory = stack.pop()
                try:
                    if (
                        reparse(directory)
                        or protected_directory(directory)
                        or self.excluded_path(directory)
                    ):
                        continue
                    key = str(directory.resolve()).casefold()
                    if key in seen:
                        continue
                    seen.add(key)
                    self.directories_seen += 1
                    if self.directories_seen % 200 == 0:
                        self.log(
                            f"ZIP 자동 검색 중: 폴더 {self.directories_seen}, 파일 {self.files_seen}"
                        )
                    with os.scandir(directory) as entries:
                        for entry in entries:
                            if not self.budget():
                                break
                            path = Path(entry.path)
                            if reparse(path):
                                continue
                            if entry.is_dir(follow_symlinks=False):
                                if protected_directory(path) or self.excluded_path(path):
                                    continue
                                if (
                                    directory.name.lower() == "users"
                                    and path.resolve() != Path.home().resolve()
                                ):
                                    continue
                                stack.append(path)
                            else:
                                self.files_seen += 1
                                if path.suffix.lower() != ".zip":
                                    continue
                                kind = classify(path)
                                if kind == "REQUIRED":
                                    self.move(path)
                                elif kind != "UNRELATED":
                                    # Sensitive names/contents are not listed in the log.
                                    self.record(kind)
                except OSError as exc:
                    self.complete = False
                    self.record("DIRECTORY_UNREADABLE", error_type=type(exc).__name__)
            if not self.budget():
                if not self.counts.get("SEARCH_LIMIT_REACHED"):
                    self.record("SEARCH_LIMIT_REACHED")
                break
        self.record("FINISHED")
        return {
            "moved": self.counts.get("MOVED", 0),
            "copied_source_retained": self.counts.get("COPIED_SOURCE_RETAINED", 0),
            "complete_within_allowed_scope": self.complete,
            "counts": self.counts,
            "journal": str(self.journal),
            "destination": str(self.destination),
        }
