"""Korean messages for fixed failure codes; never interpret arbitrary error contents."""

from __future__ import annotations

MESSAGES = {
    "DOCKER_REQUIRED": (
        "Docker 실행 파일을 찾지 못했습니다.",
        "‘Docker 준비’ 버튼으로 공식 설치 화면을 열고 설치 후 1번 TEST를 다시 실행하세요.",
    ),
    "DOCKER_ENGINE_UNAVAILABLE": (
        "Docker 엔진에 연결할 수 없습니다.",
        "Docker Desktop을 실행하고 Linux 엔진이 준비된 후 다시 검사하세요.",
    ),
    "DOCKER_START_TIMEOUT": (
        "Docker 시작 대기 시간이 지났습니다.",
        "Docker 창의 최초 약관·WSL·재시작 안내를 확인한 후 다시 검사하세요.",
    ),
    "DOCKER_DESKTOP_START_FAILED": (
        "설치된 Docker Desktop을 실행하지 못했습니다.",
        "‘Docker 준비’ 화면에서 설치 상태를 확인하세요.",
    ),
    "DOCKER_LINUX_REQUIRED": (
        "검사에는 Linux 컨테이너 엔진이 필요합니다.",
        "Docker Desktop에서 Linux 컨테이너를 선택한 후 다시 검사하세요.",
    ),
    "DOCKER_CONTEXT_UNAVAILABLE": (
        "Docker 연결 설정을 확인하지 못했습니다.",
        "Docker Desktop의 로컬 Linux 엔진이 준비된 후 다시 검사하세요.",
    ),
    "LOCAL_DOCKER_CONTEXT_REQUIRED": (
        "현재 Docker 연결이 로컬 Desktop 엔진이 아닙니다.",
        "이 PC의 로컬 Linux Docker 연결을 선택한 후 다시 검사하세요.",
    ),
    "PORT_8000_IN_USE": (
        "8000 포트를 사용 중인 프로그램이 있습니다.",
        "사용 중인 프로그램을 확인한 후 다시 검사하세요. 실행기가 강제로 종료하지 않습니다.",
    ),
    "CHECK_COMMAND_FAILED": (
        "설치 또는 백엔드 검사 명령이 실패했습니다.",
        "‘로그·원인 보기’의 검사 로그를 확인하세요. 적용하지 않았습니다.",
    ),
    "PermissionError": (
        "파일 또는 폴더 접근 권한이 부족합니다.",
        "쓰기 가능한 독립 API 대상 폴더를 선택한 후 다시 검사하세요.",
    ),
    "PAYLOAD_HASH_MISMATCH": (
        "패키지 해시가 배포 기록과 다릅니다.",
        "배포 브랜치의 시작 ZIP을 다시 받아 새 실행 화면을 여세요.",
    ),
    "UNMANAGED_TARGET_NOT_EMPTY": (
        "대상에 관리 이력을 확인할 수 없는 파일이 있습니다.",
        "새 독립 API 대상 폴더를 선택하세요. 기존 파일은 보존합니다.",
    ),
    "LOCAL_CUSTOMIZATION_STOP": (
        "기존 관리 파일의 수정이 발견됐습니다.",
        "기존 변경을 검토한 후 적용해야 합니다. 자동으로 덮어쓰지 않습니다.",
    ),
    "STAGE10_TARGET_FORBIDDEN": (
        "운영 Stage10 폴더는 설치 대상이 될 수 없습니다.",
        "별도 SAQ_INVESTOR_FLOW_API 대상 폴더를 선택하세요.",
    ),
    "TEST_NOT_PASSED": (
        "필수 검사에 실패 또는 건너뜀이 있습니다.",
        "검사를 모두 통과해야 적용할 수 있습니다.",
    ),
}


def describe(reason: object) -> tuple[str, str]:
    return MESSAGES.get(
        reason if isinstance(reason, str) else "",
        ("검사 또는 적용을 중단했습니다.", "‘로그·원인 보기’에서 저장된 원인 코드를 확인하세요."),
    )
