from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import hashlib
import html
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import socket
import stat
import subprocess
import sys
from typing import Callable, Protocol
import uuid
import zipfile

from saq_installer.diagnostics import describe
from saq_installer.docker_runtime import DockerUnavailable, ensure_docker


class Stop(RuntimeError):
    """Fixed diagnostic code; never print arbitrary exception payloads."""


def sha(path: Path) -> str:
    before = path.stat()
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise Stop("FILE_CHANGED_DURING_READ")
    return h.hexdigest()


def reparse(path: Path) -> bool:
    state = path.lstat()
    return stat.S_ISLNK(state.st_mode) or bool(getattr(state, "st_file_attributes", 0) & 0x400)


def relative(name: str) -> str:
    name = name.replace("\\", "/")
    if (
        not name
        or name.startswith("/")
        or ":" in name
        or any(ord(c) < 32 for c in name)
        or ".." in PurePosixPath(name).parts
    ):
        raise Stop("UNSAFE_PACKAGE_PATH")
    for part in PurePosixPath(name).parts:
        if part.endswith((" ", ".")) or part.split(".")[0].upper() in {
            "CON",
            "PRN",
            "AUX",
            "NUL",
            *(f"COM{i}" for i in range(1, 10)),
            *(f"LPT{i}" for i in range(1, 10)),
        }:
            raise Stop("UNSAFE_WINDOWS_PATH")
    return name


def snapshot(root: Path) -> dict[str, str] | None:
    if not root.exists():
        return None
    if not root.is_dir() or reparse(root):
        raise Stop("TARGET_NOT_PLAIN_DIRECTORY")
    result = {}
    for current, directories, files in os.walk(root, followlinks=False):
        for name in sorted(directories + files):
            path = Path(current) / name
            if reparse(path):
                raise Stop("TARGET_LINK_OR_REPARSE_POINT")
            key = path.relative_to(root).as_posix()
            result[key + "/" if path.is_dir() else key] = "DIR" if path.is_dir() else sha(path)
    return result


def atomic_json(path: Path, value: dict[str, object]) -> None:
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    with temp.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


@dataclass(frozen=True)
class Spec:
    payload_sha256: str
    accepted_manifest_hashes: tuple[str, ...] = ()
    accepted_payload_hashes: tuple[str, ...] = ()


@dataclass(frozen=True)
class Evidence:
    python: Path
    passed: int
    failed: int
    skipped: int
    directory: Path


class Runner(Protocol):
    def __call__(self, release: Path, cache: Path, log: Callable[[str], None]) -> Evidence: ...


class BackendRunner:
    def __init__(
        self,
        base_python: Path | None = None,
        reuse_python: Path | None = None,
        constraints: Path | None = None,
    ) -> None:
        self.base_python = base_python or Path(sys.executable)
        self.reuse_python = reuse_python
        self.constraints = constraints
        self.environment_updates: dict[str, str] = {}

    def command(
        self, args: list[str], cwd: Path, log: Callable[[str], None], output: Path
    ) -> None:
        env = os.environ.copy()
        env.update(self.environment_updates)
        env.pop("PYTHONPATH", None)
        env.pop("PYTHONHOME", None)
        env["PYTHONIOENCODING"] = "utf-8"
        with output.open("a", encoding="utf-8") as stream:
            process = subprocess.Popen(
                args,
                cwd=cwd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            assert process.stdout is not None
            for line in process.stdout:
                stream.write(line)
                log(line.rstrip())
            status = process.wait()
            stream.write(f"\nEXIT_CODE={status}\n")
        if status:
            raise Stop("CHECK_COMMAND_FAILED")

    def __call__(self, release: Path, cache: Path, log: Callable[[str], None]) -> Evidence:
        try:
            docker = ensure_docker(log)
        except DockerUnavailable as exc:
            raise Stop(str(exc)) from None
        self.environment_updates["PATH"] = (
            str(docker.parent) + os.pathsep + os.environ.get("PATH", "")
        )
        python = self.reuse_python
        if python is None:
            log("독립 검사용 가상환경 준비: 기존 Stage10 환경은 변경하지 않습니다.")
            env = cache / "environment"
            self.command(
                [str(self.base_python), "-m", "venv", str(env)], release, log, cache / "check.log"
            )
            python = env / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
            args = [
                str(python),
                "-m",
                "pip",
                "install",
                "--disable-pip-version-check",
                "--no-input",
            ]
            if self.constraints:
                args += ["-c", str(self.constraints)]
            self.command(args + [str(release) + "[dev]"], release, log, cache / "check.log")
        log("마이그레이션·pytest·실제 HTTP 검사를 실행합니다.")
        output = cache / "backend_evidence"
        self.command(
            [str(python), "scripts/verify_work.py", "--output", str(output)],
            release,
            log,
            cache / "check.log",
        )
        result = json.loads((output / "RESULT.json").read_text(encoding="utf-8"))
        tests = result.get("tests", {})
        if (
            result.get("status") != "REFERENCE_CODE_CHECKS_PASSED"
            or result.get("flake8_exit_code") != 0
            or result.get("integration_command_exit_code") != 0
            or tests.get("passed", 0) < 56
            or tests.get("failed") != 0
            or tests.get("skipped") != 0
            or result.get("source_unchanged_during_checks") is not True
        ):
            raise Stop("BACKEND_CHECK_NOT_PASSED")
        return Evidence(python, tests["passed"], tests["failed"], tests["skipped"], output)


class Installer:
    def __init__(
        self,
        payload: Path,
        spec: Spec,
        target: Path,
        cache: Path,
        runner: Runner,
        log: Callable[[str], None] = lambda message: None,
        fault: Callable[[str], None] | None = None,
        port_guard: Callable[[], bool] | None = None,
    ) -> None:
        self.payload, self.spec, self.target = payload, spec, target.absolute()
        self.cache, self.runner, self.log = cache.absolute(), runner, log
        self.cache.mkdir(parents=True, exist_ok=False)
        self.fault = fault or (lambda phase: None)
        self.port_guard = port_guard or self.port_open
        self.state = "NEW"
        self.release: Path | None = None
        self.managed: dict[str, str] = {}
        self.before: dict[str, str] | None = None
        self.evidence: Evidence | None = None
        self.python_sha: str | None = None
        self.result: dict[str, object] = {}

    @staticmethod
    def port_open() -> bool:
        try:
            with socket.create_connection(("127.0.0.1", 8000), timeout=0.25):
                return True
        except OSError:
            return False

    def guard_target(self) -> None:
        name = self.target.name.upper()
        if name != "SAQ_INVESTOR_FLOW_API" and not name.startswith("SAQ_INVESTOR_FLOW_API_"):
            raise Stop("INDEPENDENT_API_TARGET_REQUIRED")
        if any(
            p.name.upper() == "V7_STAGE10_DIRECT_CHART" for p in (self.target, *self.target.parents)
        ):
            raise Stop("STAGE10_TARGET_FORBIDDEN")
        for parent in (self.target, *self.target.parents):
            if parent.exists() and reparse(parent):
                raise Stop("TARGET_PARENT_REPARSE_POINT")
        if self.cache.is_relative_to(self.target) or self.target.is_relative_to(self.cache):
            raise Stop("CACHE_TARGET_OVERLAP")

    def unpack(self) -> None:
        if sha(self.payload) != self.spec.payload_sha256:
            raise Stop("PAYLOAD_HASH_MISMATCH")
        staging = self.cache / "release"
        staging.mkdir()
        with zipfile.ZipFile(self.payload) as bundle:
            infos = [entry for entry in bundle.infolist() if not entry.is_dir()]
            if len(infos) > 10000 or sum(i.file_size for i in infos) > 256 * 1024 * 1024:
                raise Stop("PACKAGE_LIMIT_EXCEEDED")
            names = [relative(i.filename) for i in infos]
            if len({n.casefold() for n in names}) != len(names):
                raise Stop("DUPLICATE_PACKAGE_PATH")
            prefixes = {n.split("/")[0] for n in names}
            if len(prefixes) != 1 or any("/" not in n for n in names):
                raise Stop("PACKAGE_LAYOUT_INVALID")
            prefix = next(iter(prefixes)) + "/"
            manifest_name = prefix + "MANIFEST_SHA256.json"
            if bundle.getinfo(manifest_name).file_size > 2 * 1024 * 1024:
                raise Stop("MANIFEST_TOO_LARGE")
            manifest_bytes = bundle.read(manifest_name)
            declared = json.loads(manifest_bytes)["files"]
            self.managed = {relative(k): v for k, v in declared.items()}
            self.managed["MANIFEST_SHA256.json"] = hashlib.sha256(manifest_bytes).hexdigest()
            if {prefix + n for n in self.managed} != set(names):
                raise Stop("UNDECLARED_PACKAGE_FILE")
            for entry in infos:
                if entry.flag_bits & 1 or stat.S_ISLNK((entry.external_attr >> 16) & 0xFFFF):
                    raise Stop("PACKAGE_LINK_OR_ENCRYPTION")
                name = entry.filename.removeprefix(prefix)
                output = staging / name
                output.parent.mkdir(parents=True, exist_ok=True)
                data = bundle.read(entry)
                if hashlib.sha256(data).hexdigest() != self.managed[name]:
                    raise Stop("MEMBER_HASH_MISMATCH")
                output.write_bytes(data)
        self.release = staging

    def verify_release(self) -> None:
        if not self.release or sha(self.payload) != self.spec.payload_sha256:
            raise Stop("RELEASE_NOT_AVAILABLE")
        for name, expected in self.managed.items():
            path = self.release / name
            if not path.is_file() or reparse(path) or sha(path) != expected:
                raise Stop("RELEASE_CHANGED")

    def old_managed(self) -> dict[str, str]:
        receipt = self.target / ".saq_install_receipt.json"
        if receipt.is_file():
            data = json.loads(receipt.read_text(encoding="utf-8"))
            if data.get("installer") != "SAQ_API_GUARDED_V1" or data.get("payload_sha256") not in (
                self.spec.payload_sha256,
                *self.spec.accepted_payload_hashes,
            ):
                raise Stop("UNKNOWN_INSTALLED_RELEASE")
            declared = data["managed"]
        else:
            manifest = self.target / "MANIFEST_SHA256.json"
            if not manifest.is_file() or sha(manifest) not in self.spec.accepted_manifest_hashes:
                raise Stop("UNMANAGED_TARGET_NOT_EMPTY")
            declared = json.loads(manifest.read_text(encoding="utf-8"))["files"]
            declared["MANIFEST_SHA256.json"] = sha(manifest)
        result = {relative(n): h for n, h in declared.items()}
        for name, expected in result.items():
            path = self.target / name
            if not path.is_file() or sha(path) != expected:
                raise Stop("LOCAL_CUSTOMIZATION_STOP")
        return result

    def target_baseline(self) -> tuple[dict[str, str] | None, dict[str, str]]:
        current = snapshot(self.target)
        if not current or not any(not name.endswith("/") for name in current):
            return current, {}
        managed = self.old_managed()
        for name in current:
            if name.endswith("/"):
                continue
            parts = PurePosixPath(name).parts
            if ".venv" in parts or "__pycache__" in parts or "VERIFICATION" in parts:
                continue
            if name not in managed and (name.endswith((".py", ".cmd")) or name in self.managed):
                raise Stop("UNMANAGED_CODE_COLLISION")
        for generated in (".saq_runtime.json", "START_API.cmd"):
            if generated in current and generated not in managed:
                raise Stop("UNMANAGED_RUNTIME_COLLISION")
        return current, managed

    def write_result(self, **extra: object) -> None:
        self.result.update(extra)
        if self.result.get("reason"):
            explanation, next_step = describe(self.result["reason"])
            self.result.update(explanation_ko=explanation, next_step_ko=next_step)
        self.result["verdict"] = (
            "PASS_CODE_TESTS_ONLY"
            if self.state == "PASS"
            else "CODE_APPLY_SUCCESS" if self.state == "SUCCESS" else self.state
        )
        self.result.update(
            state=self.state,
            target=str(self.target),
            payload_sha256=self.spec.payload_sha256,
            at=datetime.now().astimezone().isoformat(),
            scope="INDEPENDENT_API_CODE_ONLY",
            operating_database_migration="NOT_PERFORMED",
            stage10_modified=False,
            live_krx_pykrx_collection="NOT_PERFORMED",
        )
        if self.evidence:
            self.result["test_passed"] = self.evidence.passed
        atomic_json(self.cache / "RESULT.json", self.result)
        rows = "".join(
            "<tr><th>" + html.escape(str(k)) + "</th><td>" + html.escape(str(v)) + "</td></tr>"
            for k, v in self.result.items()
        )
        content = (
            '<!doctype html><meta charset="utf-8"><title>SAQ 설치 결과</title>'
            "<style>body{font:16px sans-serif;margin:32px;color:#18304a}"
            "td,th{padding:10px;border-bottom:1px solid #ddd;text-align:left}</style>"
            "<h1>SAQ 독립 수급 API — 코드 적용 결과</h1><p>운영 DB 마이그레이션·실데이터 수집·Stage10 변경은 수행하지 않았습니다.</p>"
            "<table>" + rows + "</table>"
        )
        (self.cache / "RESULT.html").write_text(content, encoding="utf-8")

    def check(self) -> bool:
        if self.state != "NEW":
            raise Stop("NEW_CHECK_INSTANCE_REQUIRED")
        self.state = "CHECKING"
        try:
            self.guard_target()
            self.before, _ = self.target_baseline()
            if self.port_guard():
                raise Stop("PORT_8000_IN_USE")
            self.unpack()
            assert self.release is not None
            self.evidence = self.runner(self.release, self.cache, self.log)
            if self.evidence.passed < 56 or self.evidence.failed or self.evidence.skipped:
                raise Stop("TEST_NOT_PASSED")
            self.python_sha = sha(self.evidence.python)
            self.verify_release()
            if snapshot(self.target) != self.before:
                raise Stop("TARGET_CHANGED_DURING_CHECK")
            self.state = "PASS"
            self.write_result(verdict="PASS_CODE_TESTS_ONLY")
            return True
        except Exception as exc:
            self.state = "STOP"
            self.write_result(
                verdict="STOP", reason=str(exc) if isinstance(exc, Stop) else type(exc).__name__
            )
            explanation, next_step = describe(self.result.get("reason"))
            self.log("STOP [" + str(self.result.get("reason")) + "] " + explanation)
            self.log(next_step)
            return False

    def apply(self) -> bool:
        if self.state != "PASS" or not self.evidence:
            raise Stop("PASS_REQUIRED")
        try:
            self.guard_target()
            self.verify_release()
            if self.port_guard() or sha(self.evidence.python) != self.python_sha:
                raise Stop("RUNTIME_CHANGED_OR_RUNNING")
            current, old_files = self.target_baseline()
            if current != self.before:
                raise Stop("TARGET_CHANGED_AFTER_PASS")
        except Exception as exc:
            self.state = "STOP"
            self.write_result(reason=str(exc) if isinstance(exc, Stop) else type(exc).__name__)
            return False
        self.target.parent.mkdir(parents=True, exist_ok=True)
        token = uuid.uuid4().hex
        incoming = self.target.with_name(".saq_incoming_" + token)
        old = self.target.with_name(".saq_before_" + token)
        failed = self.target.with_name(".saq_failed_" + token)
        lock = self.target.with_name("." + self.target.name + ".saq_lock")
        try:
            handle = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            self.state = "STOP"
            self.write_result(reason="ANOTHER_INSTALLER_ACTIVE")
            return False
        os.write(handle, token.encode())
        os.close(handle)
        moved_old = promoted = False
        self.state = "APPLYING"
        try:
            size = sum(
                (self.target / n).stat().st_size for n in (current or {}) if not n.endswith("/")
            )
            if (
                min(shutil.disk_usage(self.cache).free, shutil.disk_usage(self.target.parent).free)
                < 2 * size + 32 * 1024 * 1024
            ):
                raise Stop("INSUFFICIENT_BACKUP_SPACE")
            backup = self.cache / "BACKUP"
            if current is not None:
                shutil.copytree(self.target, backup)
                if snapshot(backup) != current:
                    raise Stop("BACKUP_VERIFICATION_FAILED")
                self.result["backup"] = str(backup)
            else:
                backup.mkdir()
                atomic_json(backup / "ORIGINAL_ABSENT.json", {"target_existed": False})
                self.result["backup"] = str(backup)
            self.fault("after_backup")
            if current is not None:
                shutil.copytree(self.target, incoming)
            else:
                incoming.mkdir()
            # Remove only unchanged files explicitly owned by the earlier release.
            for name in old_files.keys() - self.managed.keys():
                if name not in (".saq_runtime.json", "START_API.cmd"):
                    (incoming / name).unlink()
            assert self.release is not None
            for name in self.managed:
                output = incoming / name
                output.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(self.release / name, output)
            atomic_json(
                incoming / ".saq_runtime.json",
                {"python": str(self.evidence.python), "scope": "CODE_ONLY"},
            )
            launcher = (
                '@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\n'
                "if not defined DATABASE_URL (\r\n"
                " echo [STOP] Configure the independent PostgreSQL DATABASE_URL first.\r\n"
                " pause\r\n exit /b 2\r\n)\r\n"
                '"'
                + str(self.evidence.python)
                + '" -m uvicorn app.main:app --app-dir . --host 127.0.0.1 --port 8000\r\npause\r\n'
            )
            (incoming / "START_API.cmd").write_text(launcher, encoding="utf-8", newline="")
            installed = dict(self.managed)
            for name in (".saq_runtime.json", "START_API.cmd"):
                installed[name] = sha(incoming / name)
            atomic_json(
                incoming / ".saq_install_receipt.json",
                {
                    "installer": "SAQ_API_GUARDED_V1",
                    "payload_sha256": self.spec.payload_sha256,
                    "managed": installed,
                    "backup": str(backup),
                },
            )
            self.verify_release()
            if snapshot(self.target) != current:
                raise Stop("TARGET_CHANGED_BEFORE_APPLY")
            if current is not None:
                self.target.rename(old)
                moved_old = True
            self.fault("after_old_move")
            incoming.rename(self.target)
            promoted = True
            self.fault("after_promote")
            for name, expected in installed.items():
                if sha(self.target / name) != expected:
                    raise Stop("POST_APPLY_HASH_FAILED")
            self.fault("after_verify")
            self.state = "SUCCESS"
            self.write_result(
                verdict="CODE_APPLY_SUCCESS",
                previous_snapshot=str(old) if moved_old else None,
                managed_files=len(installed),
                auto_backup_verified=True,
            )
            return True
        except Exception as exc:
            reason = str(exc) if isinstance(exc, Stop) else type(exc).__name__
            try:
                if promoted and self.target.exists():
                    self.target.rename(failed)
                if moved_old:
                    old.rename(self.target)
                if snapshot(self.target) != current:
                    raise Stop("ROLLBACK_VERIFICATION_FAILED")
                self.state = "FAILED_ROLLED_BACK" if (moved_old or promoted) else "FAILED_UNCHANGED"
                self.write_result(
                    reason=reason,
                    original_state_verified=True,
                    failed_candidate=str(failed) if failed.exists() else None,
                )
            except Exception as recovery:
                self.state = "FAILED_RECOVERY_REQUIRED"
                self.write_result(
                    reason=reason,
                    recovery_error=type(recovery).__name__,
                    original_state_verified=False,
                    retained_snapshot=str(old),
                )
            return False
        finally:
            warnings = []
            if incoming.exists():
                try:
                    shutil.rmtree(incoming)
                except OSError:
                    warnings.append("TEMPORARY_COPY_RETAINED")
            try:
                if lock.is_file() and lock.read_text() == token:
                    lock.unlink()
            except OSError:
                warnings.append("OWN_LOCK_CLEANUP_REQUIRED")
            if warnings:
                self.result["cleanup_warnings"] = warnings
                try:
                    self.write_result()
                except OSError:
                    pass
