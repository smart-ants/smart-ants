"""Guarded installer for the independent investor-flow API, not Stage10 patches."""
