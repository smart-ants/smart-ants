"""Find an existing local Docker installation without changing machine configuration."""

from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import time
from typing import Callable, Mapping


class DockerUnavailable(RuntimeError):
    """A fixed reason code; never carries Docker stderr, endpoints or credentials."""


def installation_roots(environment: Mapping[str, str]) -> list[Path]:
    # Windows environment lookup is case-insensitive; dict(os.environ) is not.
    environment = {name.upper(): value for name, value in environment.items()}
    roots = []
    for base in (
        environment.get("PROGRAMW6432"),
        environment.get("PROGRAMFILES", r"C:\Program Files"),
    ):
        if base:
            root = Path(base) / "Docker/Docker"
            if root not in roots:
                roots.append(root)
    local = environment.get("LOCALAPPDATA")
    if local:
        roots.append(Path(local) / "Programs/DockerDesktop")
    return roots


def find_cli(environment: Mapping[str, str], windows: bool) -> Path | None:
    found = shutil.which("docker.exe" if windows else "docker", path=environment.get("PATH", ""))
    if found:
        return Path(found).absolute()
    if windows:
        for root in installation_roots(environment):
            candidate = root / "resources/bin/docker.exe"
            if candidate.is_file():
                return candidate.absolute()
    return None


def find_desktop(environment: Mapping[str, str]) -> Path | None:
    for root in installation_roots(environment):
        candidate = root / "Docker Desktop.exe"
        if candidate.is_file():
            return candidate.absolute()
    return None


def probe(cli: Path, environment: dict[str, str], windows: bool) -> str | None:
    options = {
        "env": environment,
        "capture_output": True,
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
        "timeout": 8,
    }
    if windows and os.name == "nt":
        options["creationflags"] = subprocess.CREATE_NO_WINDOW
    try:
        result = subprocess.run([str(cli), "info", "--format", "{{.OSType}}"], **options)
        if result.returncode:
            return "DOCKER_ENGINE_UNAVAILABLE"
        if result.stdout.strip() != "linux":
            return "DOCKER_LINUX_REQUIRED"
        if windows:
            # Do not create our temporary test container on an unrelated remote engine.
            endpoint = (
                environment.get("DOCKER_HOST") if not environment.get("DOCKER_CONTEXT") else None
            )
            if not endpoint:
                context = subprocess.run(
                    [str(cli), "context", "inspect", "--format", "{{.Endpoints.docker.Host}}"],
                    **options,
                )
                if context.returncode:
                    return "DOCKER_CONTEXT_UNAVAILABLE"
                endpoint = context.stdout.strip()
            if not endpoint.startswith(("npipe://", "unix://")):
                return "LOCAL_DOCKER_CONTEXT_REQUIRED"
        return None
    except (OSError, subprocess.TimeoutExpired):
        return "DOCKER_ENGINE_UNAVAILABLE"


def ensure_docker(
    log: Callable[[str], None],
    *,
    environment: Mapping[str, str] | None = None,
    windows: bool | None = None,
    startup_seconds: float = 90,
) -> Path:
    environment = dict(os.environ if environment is None else environment)
    windows = os.name == "nt" if windows is None else windows
    cli = find_cli(environment, windows)
    if cli is None:
        raise DockerUnavailable("DOCKER_REQUIRED")
    environment["PATH"] = str(cli.parent) + os.pathsep + environment.get("PATH", "")
    problem = probe(cli, environment, windows)
    if problem is None:
        log("Docker Linux 엔진 준비 완료.")
        return cli
    if problem != "DOCKER_ENGINE_UNAVAILABLE":
        raise DockerUnavailable(problem)
    desktop = find_desktop(environment) if windows else None
    if desktop is None:
        raise DockerUnavailable(problem)
    log("설치된 Docker Desktop을 실행합니다. 처음 실행이면 Docker 창의 동의를 직접 선택하세요.")
    try:
        subprocess.Popen(
            [str(desktop)], env=environment, cwd=desktop.parent,
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except OSError:
        raise DockerUnavailable("DOCKER_DESKTOP_START_FAILED") from None
    deadline = time.monotonic() + startup_seconds
    while time.monotonic() < deadline:
        log("Docker Linux 엔진 시작 대기 중… 설치/약관/WSL 안내가 있으면 Docker 창을 확인하세요.")
        time.sleep(min(3, max(0, deadline - time.monotonic())))
        problem = probe(cli, environment, windows)
        if problem is None:
            log("Docker Linux 엔진 준비 완료.")
            return cli
        if problem != "DOCKER_ENGINE_UNAVAILABLE":
            raise DockerUnavailable(problem)
    raise DockerUnavailable("DOCKER_START_TIMEOUT")
