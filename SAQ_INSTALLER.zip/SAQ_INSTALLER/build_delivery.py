"""Build deterministic, self-contained Windows delivery from verified backend sources."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path
import zipfile
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
STAMP = (2026, 10, 27, 0, 0, 0)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def archive(path: Path, files: dict[str, bytes], prefix: str) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(prefix + name, date_time=STAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, data)
    path.chmod(0o644)


def payload(proof: Path) -> None:
    proof_result = json.loads((proof / "RESULT.json").read_text(encoding="utf-8"))
    if (
        proof_result.get("status") != "REFERENCE_CODE_CHECKS_PASSED"
        or proof_result.get("tests", {}).get("passed", 0) < 56
        or proof_result.get("tests", {}).get("failed") != 0
        or proof_result.get("tests", {}).get("skipped") != 0
    ):
        raise RuntimeError("Current backend evidence did not pass")
    recorded = json.loads((proof / "SOURCE_SHA256.json").read_text(encoding="utf-8"))
    for name, expected in recorded.items():
        if digest((PROJECT / name).read_bytes()) != expected:
            raise RuntimeError("Source changed since verification: " + name)
    names = [
        ".gitignore", ".flake8", "AGENTS.md", "README.md", "pyproject.toml",
        "alembic.ini", "schema.sql", "openapi.json", "VERIFY_WORK.cmd",
        "docs/BACKEND_HANDOFF.md",
    ]
    for directory in ("app", "tests", "scripts", "alembic"):
        for path in sorted((PROJECT / directory).rglob("*")):
            if path.is_file() and path.suffix in (".py", ".mako"):
                names.append(path.relative_to(PROJECT).as_posix())
    names.extend(
        "REPORTS/SIX_TABLE_BACKEND_RESULT_20261027." + extension
        for extension in ("md", "json", "docx")
    )
    files = {name: (PROJECT / name).read_bytes() for name in names}
    proof_names = (
        "RESULT.json", "SOURCE_SHA256.json", "LINT.log", "POSTGRES_TESTS.log", "TESTS.xml",
    )
    for name in proof_names:
        files["PROOF/" + name] = (proof / name).read_bytes()
    files["BUILD_NOTE.md"] = (
        "# 검증된 독립 수급 API 코드\n\n"
        "PROOF/RESULT.json과 TESTS.xml은 이 소스의 PostgreSQL 16 격리 검사 결과입니다.\n"
        "PostgreSQL 초기화용 Unix 소켓 서버와 최종 TCP 서버를 구분해 준비를 기다립니다.\n"
        "56개 통과, 실패/건너뜀 0. 운영 DB·Stage10·실데이터 수집은 적용하지 않았습니다.\n"
        "Windows 자동 실행기는 별도 SAQ_START.cmd로 제공합니다.\n"
    ).encode("utf-8")
    manifest = {
        "package": "SAQ_INVESTOR_FLOW_API",
        "purpose": "Independent API reference code; no operating Stage10 changes",
        "checks": proof_result,
        "note": "SHA-256 integrity records are not publisher signatures",
        "files": {name: digest(data) for name, data in sorted(files.items())},
    }
    files["MANIFEST_SHA256.json"] = (
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    ).encode("utf-8")
    destination = ROOT / "backend_payload.zip"
    archive(destination, files, "SAQ_INVESTOR_FLOW_API/")
    spec_path = ROOT / "release.json"
    metadata = json.loads(spec_path.read_text(encoding="utf-8"))
    previous = metadata["payload_sha256"]
    metadata["payload_sha256"] = digest(destination.read_bytes())
    metadata["accepted_payload_hashes"] = sorted(
        set(metadata["accepted_payload_hashes"]) | {previous}
    )
    metadata["accepted_manifest_hashes"] = sorted(
        set(metadata["accepted_manifest_hashes"]) | {digest(files["MANIFEST_SHA256.json"])}
    )
    spec_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def delivery(output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    unit_cases = ElementTree.parse(ROOT / "UNIT_TESTS.xml").getroot().findall(".//testcase")
    if len(unit_cases) < 53 or any(
        any(case.find(tag) is not None for tag in ("failure", "error", "skipped"))
        for case in unit_cases
    ):
        raise RuntimeError("Current installer unit evidence did not pass")
    evidence = json.loads((ROOT / "REAL_INTEGRATION_RESULT.json").read_text(encoding="utf-8"))
    metadata = json.loads((ROOT / "release.json").read_text(encoding="utf-8"))
    if evidence.get("payload_sha256") != metadata["payload_sha256"]:
        raise RuntimeError("Real installer evidence is for another payload")
    if evidence.get("status") != "PASSED_LINUX_CORE_ONLY":
        raise RuntimeError("Real installer checks did not pass")
    names = [
        "RUN_INSTALLER.cmd", "backend_payload.zip", "release.json", "constraints.txt",
        "README_KO.md", "TEST_REPORT.md", "REAL_INTEGRATION_RESULT.json", "UNIT_TESTS.xml",
        "build_delivery.py", "bootstrap.ps1", "docker_setup.ps1",
    ]
    for directory in ("saq_installer", "tests"):
        names.extend(
            path.relative_to(ROOT).as_posix()
            for path in sorted((ROOT / directory).rglob("*.py"))
        )
    files = {name: (ROOT / name).read_bytes() for name in names}
    files["INSTALLER_MANIFEST_SHA256.json"] = (
        json.dumps({name: digest(data) for name, data in sorted(files.items())}, indent=2) + "\n"
    ).encode("utf-8")
    package = output / "SAQ_INSTALLER.zip"
    archive(package, files, "SAQ_INSTALLER/")
    encoded = base64.encodebytes(package.read_bytes()).decode("ascii")
    sha = digest(package.read_bytes())
    powershell = (ROOT / "bootstrap.ps1").read_text(encoding="utf-8")
    powershell = powershell.replace("__PACKAGE_SHA256__", sha)
    header = (
        "@echo off\r\nsetlocal\r\nset \"SAQ_BOOTSTRAP=%~f0\"\r\n"
        'powershell.exe -NoProfile -STA -Command "'
        "$all=[IO.File]::ReadAllText($env:SAQ_BOOTSTRAP,[Text.Encoding]::UTF8); "
        "$body=([regex]::Split($all,'(?m)^#__SAQ_PS__\\r?$'))[1]; "
        "$body=([regex]::Split($body,'(?m)^#__SAQ_PAYLOAD__\\r?$'))[0]; "
        '& ([ScriptBlock]::Create($body))"\r\n'
        'set "SAQ_RC=%ERRORLEVEL%"\r\n'
        'if not "%SAQ_RC%"=="0" pause\r\nexit /b %SAQ_RC%\r\n'
        "#__SAQ_PS__\r\n"
    )
    starter = output / "SAQ_START.cmd"
    starter.write_bytes(
        (header + powershell.replace("\n", "\r\n") + "\r\n#__SAQ_PAYLOAD__\r\n" + encoded)
        .encode("utf-8")
    )
    starter.chmod(0o644)
    starter_zip = output / "SAQ_START.zip"
    archive(starter_zip, {starter.name: starter.read_bytes()}, "")
    (output / "SAQ_INSTALLER_SHA256.json").write_text(
        json.dumps(
            {p.name: digest(p.read_bytes()) for p in (package, starter, starter_zip)}, indent=2
        ) + "\n",
        encoding="utf-8",
    )
    # Verify the bytes the bootstrap will decode, not merely the archive on disk.
    import re

    encoded_block = re.split(r"(?m)^#__SAQ_PAYLOAD__\r?$", starter.read_text(encoding="utf-8"))[1]
    assert digest(base64.b64decode(encoded_block)) == sha
    with zipfile.ZipFile(package) as bundle:
        assert bundle.testzip() is None
        for name, data in files.items():
            assert bundle.read("SAQ_INSTALLER/" + name) == data
    with zipfile.ZipFile(starter_zip) as bundle:
        assert bundle.read(starter.name) == starter.read_bytes() and bundle.testzip() is None
    print(json.dumps({"starter": str(starter), "package": str(package), "sha256": sha}))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--proof", type=Path)
    parser.add_argument("--payload-only", action="store_true")
    parser.add_argument("--output", type=Path, default=ROOT / "DELIVERY")
    args = parser.parse_args()
    if args.proof:
        payload(args.proof)
    if not args.payload_only:
        delivery(args.output)


if __name__ == "__main__":
    main()
