"""Optional real Docker/backend install and rollback verification in a disposable folder."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import tempfile
import zipfile

from saq_installer.core import BackendRunner, Installer, Spec, snapshot
from saq_installer.organizer import Organizer

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", action="append", type=Path, default=[])
    args = parser.parse_args()
    metadata = json.loads((ROOT / "release.json").read_text(encoding="utf-8"))
    spec = Spec(
        metadata["payload_sha256"],
        tuple(metadata["accepted_manifest_hashes"]),
        tuple(metadata["accepted_payload_hashes"]),
    )
    with tempfile.TemporaryDirectory(prefix="saq-installer-real-") as directory:
        temporary = Path(directory)
        target = temporary / "SAQ_INVESTOR_FLOW_API_MANAGED"
        first = Installer(
            ROOT / "backend_payload.zip", spec, target, temporary / "cache_first",
            BackendRunner(constraints=ROOT / "constraints.txt"), log=print,
        )
        assert first.check(), (first.state, first.result.get("reason"))
        assert first.apply(), (first.state, first.result.get("reason"))
        assert first.state == "SUCCESS" and first.result["auto_backup_verified"] is True
        assert first.evidence is not None
        (target / ".env").write_text("synthetic-private-marker", encoding="utf-8")
        baseline = snapshot(target)

        def fail_after_promote(phase: str) -> None:
            if phase == "after_promote":
                raise RuntimeError("Injected verification failure")

        second = Installer(
            ROOT / "backend_payload.zip", spec, target, temporary / "cache_second",
            BackendRunner(reuse_python=first.evidence.python), fault=fail_after_promote, log=print,
        )
        assert second.check(), (second.state, second.result.get("reason"))
        assert not second.apply()
        assert second.state == "FAILED_ROLLED_BACK"
        assert snapshot(target) == baseline
        assert snapshot(Path(str(second.result["backup"]))) == baseline
        assert "synthetic-private-marker" not in (second.cache / "RESULT.html").read_text()
        assert second.evidence is not None
        scattered = temporary / "scattered"
        scattered.mkdir()
        originals = {}
        if args.archive:
            for index, archive in enumerate(args.archive):
                # Keep the recognizable source name, with a unique temporary parent.
                source = scattered / str(index) / archive.name
                source.parent.mkdir()
                shutil.copy2(archive, source)
                originals[source.relative_to(scattered).as_posix()] = source.read_bytes()
        else:
            for name in ("SAQ_P9_fixture.zip", "SAQ_P10_HF1_fixture.zip"):
                source = scattered / name
                with zipfile.ZipFile(source, "w") as bundle:
                    bundle.writestr("README.md", "Synthetic archive fixture only")
                originals[name] = source.read_bytes()
        result = Organizer(temporary / "downloads", [scattered], []).run()
        assert result["moved"] == len(originals)
        for name, content in originals.items():
            assert not (scattered / name).exists()
            assert (temporary / "downloads" / Path(name).name).read_bytes() == content
        report = {
            "status": "PASSED_LINUX_CORE_ONLY",
            "at_utc": datetime.now(timezone.utc).isoformat(),
            "payload_sha256": spec.payload_sha256,
            "fresh_private_venv_dependency_install": "PASSED",
            "fresh_install": first.state,
            "fresh_backend_tests": first.evidence.passed,
            "repeat_backend_tests": second.evidence.passed,
            "failed_upgrade": second.state,
            "backup_and_restored_tree_match": True,
            "configuration_preserved": True,
            "zip_fixture_moves": result["moved"],
            "zip_fixture_origin": "copies_of_supplied_archives" if args.archive else "synthetic",
            "synthetic_data_only": True,
            "windows_gui_bootstrap": "NOT_RUN_LINUX_ENVIRONMENT",
            "user_windows_pc_modified": False,
            "operating_database_migrated": False,
            "live_provider_connected": False,
        }
        (ROOT / "REAL_INTEGRATION_RESULT.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print("REAL_WORKFLOW_PASSED: fresh install, verified backup/rollback, ZIP moves")


if __name__ == "__main__":
    main()
