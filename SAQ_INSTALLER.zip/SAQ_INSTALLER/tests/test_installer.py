from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import zipfile

import pytest

from saq_installer.core import Evidence, Installer, Spec, Stop, sha, snapshot


def fixture_package(path: Path, content: bytes = b"NEW CODE") -> tuple[Spec, dict[str, str]]:
    entries = {"app/main.py": content, "README.md": b"fixture"}
    declared = {n: hashlib.sha256(b).hexdigest() for n, b in entries.items()}
    manifest = (json.dumps({"files": declared}) + "\n").encode()
    with zipfile.ZipFile(path, "w") as z:
        for name, data in entries.items():
            z.writestr("RELEASE/" + name, data)
        z.writestr("RELEASE/MANIFEST_SHA256.json", manifest)
    return Spec(sha(path), (hashlib.sha256(manifest).hexdigest(),)), declared


def fake_runner(release: Path, cache: Path, log: object) -> Evidence:
    """Transaction fixture only; not evidence of backend installation or tests."""
    return Evidence(Path(sys.executable), 56, 0, 0, cache)


def known_target(target: Path, content: bytes = b"OLD CODE") -> str:
    (target / "app").mkdir(parents=True)
    (target / "app/main.py").write_bytes(content)
    manifest = json.dumps({"files": {"app/main.py": hashlib.sha256(content).hexdigest()}}).encode()
    (target / "MANIFEST_SHA256.json").write_bytes(manifest)
    (target / ".env").write_text("DO_NOT_LOG_PRIVATE_CONFIGURATION")
    return hashlib.sha256(manifest).hexdigest()


def make_engine(
    tmp_path: Path,
    *,
    existing: bool = False,
    fault: object = None,
    runner: object = fake_runner,
    port: bool = False,
) -> Installer:
    payload = tmp_path / "release.zip"
    spec, _ = fixture_package(payload)
    target = tmp_path / "SAQ_INVESTOR_FLOW_API"
    if existing:
        old_hash = known_target(target)
        spec = Spec(spec.payload_sha256, (old_hash, *spec.accepted_manifest_hashes))
    return Installer(
        payload,
        spec,
        target,
        tmp_path / "private_cache",
        runner,
        fault=fault,
        port_guard=lambda: port,
    )


def test_apply_cannot_bypass_pass(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    with pytest.raises(Stop, match="PASS_REQUIRED"):
        engine.apply()
    assert not engine.target.exists()


def test_fresh_install_has_receipt_and_backup_marker(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    assert engine.check() and engine.state == "PASS"
    assert not engine.target.exists()
    assert engine.apply() and engine.state == "SUCCESS"
    assert (engine.target / "app/main.py").read_bytes() == b"NEW CODE"
    assert (engine.cache / "BACKUP/ORIGINAL_ABSENT.json").exists()
    assert (engine.target / ".saq_install_receipt.json").exists()


def test_existing_backup_verified_and_private_config_preserved(tmp_path: Path) -> None:
    engine = make_engine(tmp_path, existing=True)
    before = snapshot(engine.target)
    assert engine.check() and engine.apply()
    assert snapshot(engine.cache / "BACKUP") == before
    assert (engine.target / ".env").read_text() == "DO_NOT_LOG_PRIVATE_CONFIGURATION"
    assert "DO_NOT_LOG_PRIVATE_CONFIGURATION" not in (engine.cache / "RESULT.html").read_text()


@pytest.mark.parametrize(
    "point", ["after_backup", "after_old_move", "after_promote", "after_verify"]
)
def test_failures_restore_existing_state(tmp_path: Path, point: str) -> None:
    def fault(stage: str) -> None:
        if stage == point:
            raise OSError("DO_NOT_LOG_PRIVATE_CONFIGURATION")

    engine = make_engine(tmp_path, existing=True, fault=fault)
    before = snapshot(engine.target)
    assert engine.check()
    assert not engine.apply()
    assert engine.state in ("FAILED_UNCHANGED", "FAILED_ROLLED_BACK")
    assert "PASS" not in str(engine.result["verdict"])
    assert snapshot(engine.target) == before
    assert snapshot(engine.cache / "BACKUP") == before
    assert "DO_NOT_LOG_PRIVATE_CONFIGURATION" not in (engine.cache / "RESULT.html").read_text()


def test_fresh_failure_restores_original_absence(tmp_path: Path) -> None:
    def fault(stage: str) -> None:
        if stage == "after_promote":
            raise RuntimeError("fixture")

    engine = make_engine(tmp_path, fault=fault)
    assert engine.check() and not engine.apply()
    assert engine.state == "FAILED_ROLLED_BACK"
    assert not engine.target.exists()


def test_target_change_after_pass_forces_stop(tmp_path: Path) -> None:
    engine = make_engine(tmp_path, existing=True)
    assert engine.check()
    (engine.target / ".env").write_text("USER_CHANGED_CONFIGURATION")
    assert not engine.apply() and engine.state == "STOP"
    assert (engine.target / "app/main.py").read_bytes() == b"OLD CODE"


def test_source_change_after_pass_forces_stop(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    assert engine.check()
    assert engine.release is not None
    (engine.release / "app/main.py").write_text("changed")
    assert not engine.apply() and engine.state == "STOP"
    assert not engine.target.exists()


def test_failed_tests_never_enable_apply(tmp_path: Path) -> None:
    def failed_runner(release: Path, cache: Path, log: object) -> Evidence:
        return Evidence(Path(sys.executable), 55, 1, 0, cache)

    engine = make_engine(tmp_path, runner=failed_runner)
    assert not engine.check() and engine.state == "STOP"
    with pytest.raises(Stop):
        engine.apply()
    assert not engine.target.exists()


def test_skipped_tests_are_stop(tmp_path: Path) -> None:
    def skipped(release: Path, cache: Path, log: object) -> Evidence:
        return Evidence(Path(sys.executable), 56, 0, 1, cache)

    engine = make_engine(tmp_path, runner=skipped)
    assert not engine.check()


def test_payload_corruption_stops_before_runner(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    engine.payload.write_bytes(b"not-the-archive")
    assert not engine.check() and engine.result["reason"] == "PAYLOAD_HASH_MISMATCH"


def test_modified_known_file_is_not_overwritten(tmp_path: Path) -> None:
    engine = make_engine(tmp_path, existing=True)
    (engine.target / "app/main.py").write_text("USER CUSTOM")
    assert not engine.check()
    assert engine.result["reason"] == "LOCAL_CUSTOMIZATION_STOP"
    assert (engine.target / "app/main.py").read_text() == "USER CUSTOM"


def test_unmanaged_directory_requires_new_target(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    engine.target.mkdir()
    (engine.target / "user.txt").write_text("keep")
    assert not engine.check() and engine.result["reason"] == "UNMANAGED_TARGET_NOT_EMPTY"


def test_stage10_target_blocked(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    engine.target = tmp_path / "V7_STAGE10_DIRECT_CHART" / "SAQ_INVESTOR_FLOW_API"
    assert not engine.check() and engine.result["reason"] == "STAGE10_TARGET_FORBIDDEN"


def test_parent_target_not_allowed(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    engine.target = tmp_path / "SAQ_DEV"
    assert not engine.check() and engine.result["reason"] == "INDEPENDENT_API_TARGET_REQUIRED"


def test_running_server_blocks_check(tmp_path: Path) -> None:
    engine = make_engine(tmp_path, port=True)
    assert not engine.check() and engine.result["reason"] == "PORT_8000_IN_USE"


def test_concurrent_installer_lock_is_preserved(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    assert engine.check()
    lock = engine.target.with_name("." + engine.target.name + ".saq_lock")
    lock.write_text("another-process")
    assert not engine.apply() and lock.read_text() == "another-process"


def test_repeated_install_preserves_settings_and_receipt(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    assert engine.check() and engine.apply()
    (engine.target / ".env").write_text("PRIVATE")
    another = Installer(
        engine.payload,
        engine.spec,
        engine.target,
        tmp_path / "next_cache",
        fake_runner,
        port_guard=lambda: False,
    )
    assert another.check() and another.apply()
    assert (another.target / ".env").read_text() == "PRIVATE"


def test_links_stop(tmp_path: Path) -> None:
    engine = make_engine(tmp_path, existing=True)
    outside = tmp_path / "outside"
    outside.mkdir()
    try:
        (engine.target / "linked").symlink_to(outside, target_is_directory=True)
    except OSError:
        pytest.skip("symlink unavailable on this host")
    assert not engine.check() and engine.result["reason"] == "TARGET_LINK_OR_REPARSE_POINT"


@pytest.mark.parametrize("entry", ["../escape.py", "RELEASE/../escape.py", "RELEASE/C:evil.py"])
def test_unsafe_archive_paths_stop(tmp_path: Path, entry: str) -> None:
    engine = make_engine(tmp_path)
    with zipfile.ZipFile(engine.payload, "a") as z:
        z.writestr(entry, b"bad")
    engine.spec = Spec(sha(engine.payload))
    assert not engine.check()
    assert not (tmp_path / "escape.py").exists()


def test_undeclared_files_stop(tmp_path: Path) -> None:
    engine = make_engine(tmp_path)
    with zipfile.ZipFile(engine.payload, "a") as z:
        z.writestr("RELEASE/extra.py", b"unexpected")
    engine.spec = Spec(sha(engine.payload))
    assert not engine.check() and engine.result["reason"] == "UNDECLARED_PACKAGE_FILE"


def test_rollback_failure_never_claims_success(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    original_rename = Path.rename

    def fail_rollback(self: Path, target: Path) -> Path:
        if self.name.startswith(".saq_before_"):
            raise PermissionError("synthetic rollback failure")
        return original_rename(self, target)

    def fault(stage: str) -> None:
        if stage == "after_promote":
            raise RuntimeError("synthetic apply failure")

    engine = make_engine(tmp_path, existing=True, fault=fault)
    before = snapshot(engine.target)
    assert engine.check()
    monkeypatch.setattr(Path, "rename", fail_rollback)
    assert not engine.apply()
    assert engine.state == "FAILED_RECOVERY_REQUIRED"
    assert engine.result["original_state_verified"] is False
    assert snapshot(engine.cache / "BACKUP") == before
