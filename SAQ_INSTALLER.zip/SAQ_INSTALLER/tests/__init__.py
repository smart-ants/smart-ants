"""Disposable installer test fixtures and optional real workflow runner."""
