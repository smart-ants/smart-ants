from __future__ import annotations
import json
from pathlib import Path
import zipfile

import pytest

from saq_installer.organizer import Organizer, classify, copy_exclusive, recent_organization

NAME = "SMART_ANT_QUANTUM_STAGE10_P10_HF1_PYKRX_TEST_AUTOSYNC_CHECK_APPLY_20261027.zip"


def make_zip(path: Path, content: bytes = b"fixture") -> bytes:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("README.md", content)
    return path.read_bytes()


def test_auto_creates_folder_and_moves_after_verified_copy(tmp_path: Path) -> None:
    source = tmp_path / "scattered" / NAME
    original = make_zip(source)
    destination = tmp_path / "downloads"
    result = Organizer(destination, [source.parent], []).run()
    assert result["moved"] == 1
    assert not source.exists()
    assert (destination / NAME).read_bytes() == original
    journal = json.loads(Path(result["journal"]).read_text())
    states = [row["state"] for row in journal["records"]]
    assert states.index("COPY_VERIFIED") < states.index("MOVED")


def test_same_name_different_contents_both_preserved(tmp_path: Path) -> None:
    first = tmp_path / "one" / NAME
    second = tmp_path / "two" / NAME
    data1 = make_zip(first, b"one")
    data2 = make_zip(second, b"two")
    target = tmp_path / "downloads"
    result = Organizer(target, [first.parent, second.parent], []).run()
    assert result["moved"] == 2
    contents = {p.read_bytes() for p in target.glob("*.zip")}
    assert contents == {data1, data2}


def test_identical_duplicates_not_discarded(tmp_path: Path) -> None:
    first = tmp_path / "one" / NAME
    second = tmp_path / "two" / NAME
    data = make_zip(first)
    second.parent.mkdir()
    second.write_bytes(data)
    target = tmp_path / "downloads"
    result = Organizer(target, [first.parent, second.parent], []).run()
    assert result["moved"] == 2
    assert len(list(target.glob("*.zip"))) == 2


def test_source_change_after_copy_never_deleted(tmp_path: Path) -> None:
    source = tmp_path / "one" / NAME
    data = make_zip(source)

    def change(original: Path, copied: Path) -> None:
        original.write_bytes(b"user-updated-file")

    target = tmp_path / "downloads"
    result = Organizer(target, [source.parent], [], after_copy=change).run()
    assert result["moved"] == 0
    assert source.read_bytes() == b"user-updated-file"
    assert (target / NAME).read_bytes() == data


def test_existing_destination_not_overwritten(tmp_path: Path) -> None:
    source = tmp_path / "one" / NAME
    data = make_zip(source)
    target = tmp_path / "downloads"
    target.mkdir()
    existing = target / NAME
    existing.write_bytes(b"existing-user-file")
    result = Organizer(target, [source.parent], []).run()
    assert result["moved"] == 1 and existing.read_bytes() == b"existing-user-file"
    assert any(p.read_bytes() == data for p in target.glob("*.zip"))


def test_sensitive_archive_and_production_database_not_collected(tmp_path: Path) -> None:
    source = tmp_path / "one" / NAME
    source.parent.mkdir()
    with zipfile.ZipFile(source, "w") as z:
        z.writestr(".env", "DO_NOT_EXPORT_SECRET")
    target = tmp_path / "downloads"
    result = Organizer(target, [source.parent], []).run()
    assert source.exists() and result["moved"] == 0
    assert "DO_NOT_EXPORT_SECRET" not in Path(result["journal"]).read_text()
    assert not list(target.glob("*.zip"))


def test_backups_operating_project_and_current_installer_excluded(tmp_path: Path) -> None:
    paths = [
        tmp_path / "BACKUPS" / NAME,
        tmp_path / "V7_STAGE10_DIRECT_CHART" / NAME,
        tmp_path / "current_installer" / NAME,
    ]
    for path in paths:
        make_zip(path)
    result = Organizer(tmp_path / "downloads", [tmp_path], [tmp_path / "current_installer"]).run()
    assert result["moved"] == 0 and all(p.exists() for p in paths)


def test_unrelated_zip_not_moved(tmp_path: Path) -> None:
    path = tmp_path / "one/unrelated.zip"
    make_zip(path)
    result = Organizer(tmp_path / "downloads", [path.parent], []).run()
    assert result["moved"] == 0 and path.exists()


def test_renamed_patch_identified_by_manifest(tmp_path: Path) -> None:
    path = tmp_path / "one/renamed.zip"
    path.parent.mkdir()
    with zipfile.ZipFile(path, "w") as z:
        z.writestr(
            "release/PATCH_MANIFEST.json", json.dumps({"id": "SAQ-P10-INVESTOR-FLOW-TEST-20261026"})
        )
    assert classify(path) == "REQUIRED"
    result = Organizer(tmp_path / "downloads", [path.parent], []).run()
    assert result["moved"] == 1 and not path.exists()


def test_corrupt_zip_retained_and_recorded(tmp_path: Path) -> None:
    path = tmp_path / "one" / NAME
    path.parent.mkdir()
    path.write_bytes(b"not a zip")
    result = Organizer(tmp_path / "downloads", [path.parent], []).run()
    assert path.exists() and result["moved"] == 0
    assert result["counts"]["UNVERIFIED_ARCHIVE"] == 1


def test_scan_limit_does_not_claim_complete(tmp_path: Path) -> None:
    for number in range(3):
        make_zip(tmp_path / "one" / (str(number) + NAME))
    result = Organizer(tmp_path / "downloads", [tmp_path / "one"], [], max_files=1).run()
    assert result["complete_within_allowed_scope"] is False


def test_exclusive_copy_does_not_overwrite(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.write_bytes(b"source")
    destination = tmp_path / "existing"
    destination.write_bytes(b"user")
    with pytest.raises(FileExistsError):
        copy_exclusive(source, destination)
    assert destination.read_bytes() == b"user"


def test_destination_not_rescanned_and_repeat_is_noop(tmp_path: Path) -> None:
    source = tmp_path / "one" / NAME
    make_zip(source)
    target = tmp_path / "downloads"
    first = Organizer(target, [tmp_path], []).run()
    second = Organizer(target, [tmp_path], []).run()
    assert first["moved"] == 1 and second["moved"] == 0
    assert len(list(target.glob("*.zip"))) == 1


def test_finished_search_reused_as_history_without_moving_again(tmp_path: Path) -> None:
    source = tmp_path / "one" / NAME
    make_zip(source)
    target = tmp_path / "downloads"
    result = Organizer(target, [source.parent], []).run()
    history = recent_organization(target)
    assert result["moved"] == 1
    assert history == {"moved": 1, "complete_within_allowed_scope": True, "historical": True}


def test_incomplete_search_is_not_cached(tmp_path: Path) -> None:
    target = tmp_path / "downloads"
    make_zip(tmp_path / "one" / NAME)
    result = Organizer(target, [tmp_path / "one"], [], max_files=0).run()
    assert result["complete_within_allowed_scope"] is False
    assert recent_organization(target) is None


def test_old_search_is_not_reused(tmp_path: Path) -> None:
    target = tmp_path / "downloads"
    Organizer(target, [], []).run()
    journal = next((target / ".saq_zip_moves").glob("*.json"))
    assert recent_organization(target, now=journal.stat().st_mtime + 86401) is None
