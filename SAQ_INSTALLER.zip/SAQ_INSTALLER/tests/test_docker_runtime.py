from __future__ import annotations

import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest

from saq_installer import docker_runtime as runtime
from saq_installer.core import BackendRunner, Stop
from tests.test_installer import make_engine


def installation(tmp_path: Path, *, user: bool = False) -> tuple[dict[str, str], Path, Path]:
    environment = {
        "PATH": "",
        "ProgramFiles": str(tmp_path / "machine"),
        "LOCALAPPDATA": str(tmp_path / "user"),
    }
    root = runtime.installation_roots(environment)[1 if user else 0]
    cli = root / "resources/bin/docker.exe"
    cli.parent.mkdir(parents=True)
    cli.write_bytes(b"Fixture, never executed")
    desktop = root / "Docker Desktop.exe"
    desktop.write_bytes(b"Fixture, never executed")
    return environment, cli, desktop


@pytest.mark.parametrize("user", [False, True])
def test_installed_cli_found_when_missing_from_path(tmp_path: Path, user: bool) -> None:
    environment, cli, desktop = installation(tmp_path, user=user)
    assert runtime.find_cli(environment, True) == cli
    assert runtime.find_desktop(environment) == desktop
    assert environment["PATH"] == ""


def test_missing_docker_is_specific_stop(tmp_path: Path) -> None:
    environment = {"PATH": "", "ProgramFiles": str(tmp_path)}
    with pytest.raises(runtime.DockerUnavailable, match="^DOCKER_REQUIRED$"):
        runtime.ensure_docker(lambda line: None, environment=environment, windows=True)


def test_native_program_files_found_from_uppercase_windows_environment(tmp_path: Path) -> None:
    environment = {
        "PATH": "", "PROGRAMFILES": str(tmp_path / "x86"),
        "PROGRAMW6432": str(tmp_path / "native"),
    }
    cli = tmp_path / "native/Docker/Docker/resources/bin/docker.exe"
    cli.parent.mkdir(parents=True)
    cli.write_bytes(b"Fixture, never executed")
    assert runtime.find_cli(environment, True) == cli


def test_running_linux_engine_does_not_launch_desktop(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment, cli, _ = installation(tmp_path)
    calls = []

    def run(args: list[str], **kwargs: object) -> SimpleNamespace:
        calls.append(args)
        assert kwargs["env"]["PATH"].startswith(str(cli.parent))
        text = "npipe:////./pipe/dockerDesktopLinuxEngine" if "context" in args else "linux"
        return SimpleNamespace(returncode=0, stdout=text)

    monkeypatch.setattr(runtime.subprocess, "run", run)
    monkeypatch.setattr(
        runtime.subprocess, "Popen", lambda *a, **k: pytest.fail("Unexpected launch")
    )
    assert runtime.ensure_docker(lambda line: None, environment=environment, windows=True) == cli
    assert len(calls) == 2
    assert environment["PATH"] == ""


def test_existing_desktop_starts_once_and_waits_for_linux(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment, cli, desktop = installation(tmp_path)
    outcomes = iter(["DOCKER_ENGINE_UNAVAILABLE", None])
    launches = []
    monkeypatch.setattr(runtime, "probe", lambda *args: next(outcomes))
    monkeypatch.setattr(runtime.time, "sleep", lambda seconds: None)
    monkeypatch.setattr(runtime.subprocess, "Popen", lambda args, **kw: launches.append(args))
    assert runtime.ensure_docker(lambda line: None, environment=environment, windows=True) == cli
    assert launches == [[str(desktop)]]


def test_windows_container_mode_stops_without_switching_engine(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment, _, _ = installation(tmp_path)
    monkeypatch.setattr(
        runtime.subprocess, "run", lambda *a, **kw: SimpleNamespace(returncode=0, stdout="windows")
    )
    monkeypatch.setattr(
        runtime.subprocess, "Popen", lambda *a, **k: pytest.fail("Unexpected launch")
    )
    with pytest.raises(runtime.DockerUnavailable, match="^DOCKER_LINUX_REQUIRED$"):
        runtime.ensure_docker(lambda line: None, environment=environment, windows=True)


def test_remote_endpoint_is_not_used_or_exported(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment, _, _ = installation(tmp_path)
    environment["DOCKER_HOST"] = "tcp://PRIVATE_ENDPOINT_WITH_SECRET:2376"
    monkeypatch.setattr(
        runtime.subprocess, "run", lambda *a, **kw: SimpleNamespace(returncode=0, stdout="linux")
    )
    with pytest.raises(runtime.DockerUnavailable) as caught:
        runtime.ensure_docker(lambda line: None, environment=environment, windows=True)
    assert str(caught.value) == "LOCAL_DOCKER_CONTEXT_REQUIRED"
    assert "PRIVATE" not in str(caught.value)


def test_startup_timeout_is_not_pass(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment, _, _ = installation(tmp_path)
    monkeypatch.setattr(runtime, "probe", lambda *args: "DOCKER_ENGINE_UNAVAILABLE")
    monkeypatch.setattr(runtime.subprocess, "Popen", lambda *args, **kw: None)
    with pytest.raises(runtime.DockerUnavailable, match="^DOCKER_START_TIMEOUT$"):
        runtime.ensure_docker(
            lambda line: None, environment=environment, windows=True, startup_seconds=0
        )


def test_nested_commands_receive_cli_path_without_changing_global_environment(
    tmp_path: Path,
) -> None:
    directory = tmp_path / "not_on_path"
    directory.mkdir()
    cli = directory / ("docker.exe" if os.name == "nt" else "docker")
    cli.write_bytes(b"Fixture")
    cli.chmod(0o755)
    runner = BackendRunner()
    old_path = os.environ.get("PATH", "")
    runner.environment_updates["PATH"] = str(directory) + os.pathsep + old_path
    output = tmp_path / "check.log"
    runner.command(
        [sys.executable, "-c", "import shutil; print(shutil.which('docker'))"],
        tmp_path, lambda line: None, output,
    )
    assert str(cli) in output.read_text()
    assert os.environ.get("PATH", "") == old_path


def test_docker_failure_is_visible_in_result_log_and_gate(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    def unavailable(log: object) -> Path:
        raise runtime.DockerUnavailable("DOCKER_REQUIRED")

    monkeypatch.setattr("saq_installer.core.ensure_docker", unavailable)
    engine = make_engine(tmp_path, runner=BackendRunner())
    logs = []
    engine.log = logs.append
    assert not engine.check()
    report = json.loads((engine.cache / "RESULT.json").read_text())
    assert report["reason"] == "DOCKER_REQUIRED"
    assert "Docker 실행 파일" in report["explanation_ko"]
    assert "Docker 준비" in report["next_step_ko"]
    assert any("DOCKER_REQUIRED" in line for line in logs)
    assert not engine.target.exists()
    with pytest.raises(Stop, match="PASS_REQUIRED"):
        engine.apply()
