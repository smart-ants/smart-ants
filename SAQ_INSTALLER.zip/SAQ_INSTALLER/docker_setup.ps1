# Windows PowerShell 5.1 helper. Windows runtime has not been tested in Linux.
# No policy, registry, context, WSL, service, membership or reboot changes.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:work = @{ Phase='idle'; Client=$null; Task=$null; Partial=$null; File=$null;
    Hash=$null; Installer=$null; Probe=$null; ProbeOut=$null; ProbeError=$null;
    ProbeAt=[DateTime]::MinValue; NextProbe=[DateTime]::MinValue;
    Deadline=[DateTime]::MinValue; Docker=$null; Desktop=$null;
    Signature=$null; SignatureOut=$null; SignatureError=$null; Purpose=$null; Guard=$null }
$cache = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SMART_ANT_QUANTUM\API_INSTALLER'
$download = 'C:\SAQ_AUDIT\DOWNLOADS'
$settings = Join-Path $cache 'bootstrap_settings.json'
if (Test-Path -LiteralPath $settings -PathType Leaf) {
    try {
        $saved = Get-Content -LiteralPath $settings -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($saved.download_directory -and [IO.Path]::IsPathRooted([string]$saved.download_directory)) {
            $download = [string]$saved.download_directory
        }
    } catch { }
}
$download = [IO.Path]::GetFullPath($download)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'SAQ · Docker 준비'
$form.Size = New-Object System.Drawing.Size(790,515)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Malgun Gothic',10)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$title = New-Object System.Windows.Forms.Label
$title.Text = 'Docker 실행 환경 준비'
$title.Font = New-Object System.Drawing.Font('Malgun Gothic',18,[Drawing.FontStyle]::Bold)
$title.SetBounds(22,18,735,44)
$form.Controls.Add($title)
$note = New-Object System.Windows.Forms.Label
$note.Text = '설치된 Docker 자동 검색·실행 → Linux 엔진 확인. 없으면 공식 설치 파일을 준비합니다.'
$note.SetBounds(24,72,725,46)
$form.Controls.Add($note)
$status = New-Object System.Windows.Forms.Label
$status.SetBounds(24,126,725,94)
$status.ForeColor = [Drawing.Color]::DarkBlue
$form.Controls.Add($status)
$progress = New-Object System.Windows.Forms.ProgressBar
$progress.SetBounds(24,230,725,24)
$form.Controls.Add($progress)
$start = New-Object System.Windows.Forms.Button
$start.Text = '기존 Docker 실행·재확인'
$start.SetBounds(24,276,235,47)
$form.Controls.Add($start)
$get = New-Object System.Windows.Forms.Button
$get.Text = '공식 설치 파일 받기'
$get.SetBounds(269,276,235,47)
$form.Controls.Add($get)
$install = New-Object System.Windows.Forms.Button
$install.Text = '공식 설치 실행'
$install.SetBounds(514,276,235,47)
$install.Enabled = $false
$form.Controls.Add($install)
$open = New-Object System.Windows.Forms.Button
$open.Text = '저장 폴더 열기'
$open.SetBounds(24,335,235,39)
$form.Controls.Add($open)
$close = New-Object System.Windows.Forms.Button
$close.Text = '닫기'
$close.SetBounds(514,335,235,39)
$close.Add_Click({ $form.Close() })
$form.Controls.Add($close)
$scope = New-Object System.Windows.Forms.Label
$scope.Text = 'ChatGPT/Codex 결제와 별도인 로컬 실행 환경입니다. 이 화면은 PASS 판정이나 API 적용을 하지 않습니다.' +
    "`r`n공식 설치창의 약관·Windows/UAC·WSL 안내는 직접 확인하세요. 설치·실행 후 원래 창의 1 TEST를 다시 누르세요."
$scope.SetBounds(24,393,725,68)
$form.Controls.Add($scope)

function Set-StateText([string]$text, [bool]$failed=$false) {
    $status.Text = $text
    $status.ForeColor = if ($failed) { [Drawing.Color]::Firebrick } else { [Drawing.Color]::DarkBlue }
}

function Stop-Probe {
    if ($script:work.Probe) {
        try { if (-not $script:work.Probe.HasExited) { $script:work.Probe.Kill() } } catch { }
        try { $script:work.Probe.Dispose() } catch { }
        $script:work.Probe = $null
    }
}

function Find-Docker {
    $script:work.Docker = $null
    $script:work.Desktop = $null
    $roots = @()
    foreach ($base in @($env:ProgramW6432, $env:ProgramFiles)) {
        if ($base) { $roots += Join-Path $base 'Docker\Docker' }
    }
    $local = [Environment]::GetFolderPath('LocalApplicationData')
    if ($local) { $roots += Join-Path $local 'Programs\DockerDesktop' }
    foreach ($root in ($roots | Select-Object -Unique)) {
        $cli = Join-Path $root 'resources\bin\docker.exe'
        $desktop = Join-Path $root 'Docker Desktop.exe'
        if (-not $script:work.Docker -and (Test-Path -LiteralPath $cli -PathType Leaf)) {
            $script:work.Docker = $cli
        }
        if (-not $script:work.Desktop -and (Test-Path -LiteralPath $desktop -PathType Leaf)) {
            $script:work.Desktop = $desktop
        }
    }
    if (-not $script:work.Docker) {
        $command = Get-Command docker.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($command) { $script:work.Docker = $command.Source }
    }
}

function Set-Idle {
    $script:work.Phase = 'idle'
    $progress.Style = 'Blocks'
    $progress.Value = 0
    $start.Enabled = $true
    $get.Enabled = $true
}

function Start-EngineCheck {
    Stop-Probe
    Find-Docker
    if (-not $script:work.Docker -and -not $script:work.Desktop) {
        Set-StateText 'STOP — Docker 실행 파일이 없습니다. 공식 설치 파일 받기를 누르세요.' $true
        return
    }
    if ($script:work.Desktop) {
        # Normal GUI start only. Do not elevate or accept the vendor agreement.
        Start-Process -FilePath $script:work.Desktop | Out-Null
    }
    $script:work.Deadline = [DateTime]::UtcNow.AddSeconds(120)
    $script:work.NextProbe = [DateTime]::MinValue
    $script:work.Phase = 'engine'
    $progress.Style = 'Marquee'
    $start.Enabled = $false
    $get.Enabled = $false
    Set-StateText 'Docker 준비 확인 중입니다. 첫 실행 약관이나 Windows 안내가 뜨면 직접 확인하세요. 최대 2분 기다립니다.'
}

function Stop-Verification {
    if ($script:work.Signature) {
        try {
            if (-not $script:work.Signature.HasExited) {
                $script:work.Signature.Kill()
                [void]$script:work.Signature.WaitForExit(2000)
            }
            $script:work.Signature.Dispose()
        } catch { }
        $script:work.Signature = $null
    }
    if ($script:work.Guard) { $script:work.Guard.Dispose(); $script:work.Guard=$null }
}

function Start-Verification([string]$file, [string]$purpose) {
    # An isolated validator keeps revocation checks off the UI thread and can be stopped on timeout.
    # EncodedCommand transports only this static validator; it changes no execution policy.
    $code = @'
$ErrorActionPreference = 'Stop'
try {
    $file = $env:SAQ_DOCKER_VERIFY_FILE
    $signature = Get-AuthenticodeSignature -LiteralPath $file -ErrorAction Stop
    if ($signature.Status -ne 'Valid' -or -not $signature.SignerCertificate) { exit 2 }
    $publisher = $signature.SignerCertificate.GetNameInfo(
        [System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $false)
    if ($publisher -notin @('Docker Inc', 'Docker Inc.')) { exit 2 }
    (Get-FileHash -LiteralPath $file -Algorithm SHA256 -ErrorAction Stop).Hash
    exit 0
} catch { exit 2 }
'@
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($code))
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = Join-Path $PSHOME 'powershell.exe'
    $info.Arguments = '-NoProfile -NonInteractive -OutputFormat Text -EncodedCommand ' + $encoded
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.EnvironmentVariables['SAQ_DOCKER_VERIFY_FILE'] = $file
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $info
    [void]$process.Start()
    $script:work.Signature = $process
    $script:work.SignatureOut = $process.StandardOutput.ReadToEndAsync()
    $script:work.SignatureError = $process.StandardError.ReadToEndAsync()
    $script:work.Purpose = $purpose
    $script:work.Phase = 'verify'
    $script:work.Deadline = [DateTime]::UtcNow.AddSeconds(120)
    $start.Enabled = $false
    $get.Enabled = $false
    $install.Enabled = $false
    $progress.Style = 'Marquee'
    Set-StateText 'Docker Inc 발행자·Authenticode 서명·파일 해시를 검증하고 있습니다. 최대 2분 기다립니다.'
}

function Start-Download {
    Stop-Probe
    $script:work.Hash = $null
    $install.Enabled = $false
    if ($download -match '(?i)(^|[\\/])V7_STAGE10_DIRECT_CHART([\\/]|$)') {
        throw 'OPERATING_STAGE10_DOWNLOAD_PATH_FORBIDDEN'
    }
    $architecture = $env:PROCESSOR_ARCHITEW6432
    if (-not $architecture) { $architecture = $env:PROCESSOR_ARCHITECTURE }
    $arch = if ($architecture -eq 'ARM64') { 'arm64' } elseif ($architecture -eq 'AMD64') { 'amd64' } else { $null }
    if (-not $arch) { throw 'UNSUPPORTED_WINDOWS_ARCHITECTURE' }
    [IO.Directory]::CreateDirectory($download) | Out-Null
    $stem = 'Docker_Desktop_Installer_' + $arch + '_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N')
    $script:work.File = Join-Path $download ($stem + '.exe')
    $script:work.Partial = Join-Path $download ($stem + '.partial.exe')
    if ((Test-Path -LiteralPath $script:work.File) -or (Test-Path -LiteralPath $script:work.Partial)) {
        throw 'DOWNLOAD_NAME_COLLISION'
    }
    # Official links from Docker's Windows installation documentation. Normal TLS/proxy validation.
    $uri = [Uri]('https://desktop.docker.com/win/main/' + $arch + '/Docker%20Desktop%20Installer.exe')
    $script:work.Client = New-Object System.Net.WebClient
    $script:work.Task = $script:work.Client.DownloadFileTaskAsync($uri, $script:work.Partial)
    $script:work.Phase = 'download'
    $progress.Style = 'Marquee'
    $start.Enabled = $false
    $get.Enabled = $false
    Set-StateText '공식 Docker 설치 파일을 다운로드하고 있습니다. 기존 파일은 덮어쓰지 않습니다.'
}

$start.Add_Click({
    try { Start-EngineCheck } catch { Set-Idle; Set-StateText 'STOP — Docker 실행 준비에 실패했습니다. 설치된 Desktop 상태를 확인하세요.' $true }
})
$get.Add_Click({
    try { Start-Download } catch { Set-Idle; Set-StateText 'STOP — 공식 다운로드를 시작하지 못했습니다. 저장 권한·Windows 아키텍처·네트워크를 확인하세요.' $true }
})
$open.Add_Click({
    try {
        if ($download -match '(?i)(^|[\\/])V7_STAGE10_DIRECT_CHART([\\/]|$)') { throw 'OPERATING_PATH' }
        [IO.Directory]::CreateDirectory($download) | Out-Null
        Start-Process explorer.exe -ArgumentList ('"' + $download + '"') | Out-Null
    } catch { Set-StateText 'STOP — 저장 폴더를 열지 못했습니다. 운영 V7 경로는 사용할 수 없습니다.' $true }
})
$install.Add_Click({
    $install.Enabled = $false
    try {
        # Keep the verified executable read-locked through the launch; do not accept arguments from downloaded data.
        Stop-Probe
        if (-not $script:work.Hash) { throw 'NO_VERIFIED_INSTALLER' }
        $script:work.Guard = [IO.File]::Open($script:work.File, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
        Start-Verification $script:work.File 'install'
    } catch {
        Stop-Verification
        Set-Idle
        Set-StateText 'STOP — 서명·파일 상태 또는 설치창 실행 확인에 실패했습니다. 설치 완료로 처리하지 않았습니다.' $true
    }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
    try {
        if ($script:work.Phase -eq 'download') {
            if (-not $script:work.Task.IsCompleted) {
                if (Test-Path -LiteralPath $script:work.Partial -PathType Leaf) {
                    $bytes = (Get-Item -LiteralPath $script:work.Partial).Length
                    if ($bytes -gt 2147483648) { $script:work.Client.CancelAsync(); throw 'DOWNLOAD_SIZE_LIMIT' }
                    Set-StateText ('공식 설치 파일 다운로드 중: ' + [Math]::Round($bytes / 1MB, 1) + ' MB. 완료 후 Docker 발행자 서명을 검증합니다.')
                }
                return
            }
            $script:work.Task.GetAwaiter().GetResult() | Out-Null
            $script:work.Client.Dispose()
            $script:work.Client = $null
            # Preserve the Internet security-zone mark on filesystems with NTFS streams.
            try { [IO.File]::WriteAllText(($script:work.Partial + ':Zone.Identifier'), "[ZoneTransfer]`r`nZoneId=3`r`nHostUrl=https://desktop.docker.com/`r`n") } catch { }
            Start-Verification $script:work.Partial 'download'
        } elseif ($script:work.Phase -eq 'verify') {
            if ([DateTime]::UtcNow -gt $script:work.Deadline) { throw 'SIGNATURE_CHECK_TIMEOUT' }
            if (-not $script:work.Signature.HasExited -or -not $script:work.SignatureOut.IsCompleted -or -not $script:work.SignatureError.IsCompleted) { return }
            $verified = $script:work.SignatureOut.Result.Trim()
            if ($script:work.Signature.ExitCode -ne 0 -or $verified -notmatch '^[A-Fa-f0-9]{64}$') {
                throw 'SIGNATURE_VERIFICATION_FAILED'
            }
            $script:work.Signature.Dispose()
            $script:work.Signature = $null
            if ($script:work.Purpose -eq 'download') {
                [IO.File]::Move($script:work.Partial, $script:work.File)
                $script:work.Hash = $verified
                Set-Idle
                $install.Enabled = $true
                Set-StateText 'Docker Inc 서명 검증 완료. 공식 설치 실행 버튼을 누르세요. 아직 설치하거나 API를 적용하지 않았습니다.'
            } else {
                if ($verified -ne $script:work.Hash) { throw 'INSTALLER_CHANGED' }
                $script:work.Installer = Start-Process -FilePath $script:work.File -PassThru
                $script:work.Guard.Dispose()
                $script:work.Guard = $null
                $script:work.Phase = 'install'
                Set-StateText '공식 설치창을 열었습니다. 설치 방식·약관·Windows/UAC 안내는 직접 확인하세요. 설치 완료 여부를 기다립니다.'
            }
        } elseif ($script:work.Phase -eq 'install') {
            if ($script:work.Installer -and $script:work.Installer.HasExited) {
                Set-Idle
                Find-Docker
                if ($script:work.Desktop -or $script:work.Docker) { Start-EngineCheck }
                else { Set-StateText '설치창이 종료됐지만 Docker 실행 파일은 아직 확인되지 않습니다. 설치창 결과를 확인하고 다시 시도하세요.' $true }
            }
        } elseif ($script:work.Phase -eq 'engine') {
            $now = [DateTime]::UtcNow
            if ($now -gt $script:work.Deadline) {
                Stop-Probe
                Set-Idle
                Set-StateText 'STOP — Linux 엔진 준비를 확인하지 못했습니다. Desktop의 첫 실행 약관·Windows/WSL 안내를 확인한 뒤 재확인하세요. TEST는 아직 통과하지 않았습니다.' $true
                return
            }
            if ($script:work.Probe) {
                if ($script:work.Probe.HasExited -and $script:work.ProbeOut.IsCompleted -and $script:work.ProbeError.IsCompleted) {
                    $osType = $script:work.ProbeOut.Result.Trim()
                    $exitCode = $script:work.Probe.ExitCode
                    Stop-Probe
                    $script:work.NextProbe = $now.AddSeconds(3)
                    if ($exitCode -eq 0 -and $osType -eq 'linux') {
                        Set-Idle
                        $status.ForeColor = [Drawing.Color]::DarkGreen
                        $status.Text = 'Linux 엔진 응답을 확인했습니다. 원래 SAQ 창의 1 TEST를 다시 실행하세요. 이 확인만으로 PASS나 API 적용 성공을 표시하지 않습니다.'
                    } elseif ($exitCode -eq 0 -and $osType -eq 'windows') {
                        Set-Idle
                        Set-StateText 'STOP — Windows 컨테이너 엔진입니다. Desktop에서 Linux 컨테이너를 선택한 뒤 재확인하세요. 엔진 모드는 자동 변경하지 않았습니다.' $true
                    }
                } elseif (($now - $script:work.ProbeAt).TotalSeconds -gt 10) {
                    Stop-Probe
                    $script:work.NextProbe = $now.AddSeconds(3)
                }
            } elseif ($now -ge $script:work.NextProbe) {
                Find-Docker
                if ($script:work.Docker) {
                    $info = New-Object System.Diagnostics.ProcessStartInfo
                    $info.FileName = $script:work.Docker
                    $info.Arguments = 'info --format "{{.OSType}}"'
                    $info.UseShellExecute = $false
                    $info.CreateNoWindow = $true
                    $info.RedirectStandardOutput = $true
                    $info.RedirectStandardError = $true
                    $process = New-Object System.Diagnostics.Process
                    $process.StartInfo = $info
                    [void]$process.Start()
                    $script:work.Probe = $process
                    $script:work.ProbeAt = $now
                    $script:work.ProbeOut = $process.StandardOutput.ReadToEndAsync()
                    $script:work.ProbeError = $process.StandardError.ReadToEndAsync()
                } else { $script:work.NextProbe = $now.AddSeconds(3) }
            }
        }
    } catch {
        Stop-Probe
        Stop-Verification
        if ($script:work.Client) { try { $script:work.Client.CancelAsync(); $script:work.Client.Dispose() } catch { }; $script:work.Client=$null }
        $install.Enabled = $false
        Set-Idle
        Set-StateText 'STOP — 다운로드·서명 검증·준비 확인 중 오류가 발생했습니다. 설치 실행이나 PASS로 처리하지 않았습니다. 네트워크·저장 권한·공식 설치창 상태를 확인하세요.' $true
    }
})
$form.Add_Shown({
    $timer.Start()
    try {
        Find-Docker
        if ($script:work.Desktop -or $script:work.Docker) { Start-EngineCheck }
        else { Start-Download }
    } catch { Set-Idle; Set-StateText 'STOP — Docker 준비를 시작하지 못했습니다. 저장 권한·Windows 아키텍처·네트워크를 확인하세요.' $true }
})
$form.Add_FormClosing({
    $timer.Stop()
    Stop-Probe
    Stop-Verification
    if ($script:work.Client) { try { $script:work.Client.CancelAsync(); $script:work.Client.Dispose() } catch { } }
    # A vendor installer or Desktop already opened by the user is deliberately left running.
})
[void]$form.ShowDialog()
$timer.Dispose()
