@echo off
setlocal
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 goto py
where python >nul 2>nul
if not errorlevel 1 goto python
echo [STOP] Existing Python 3.11+ is required. No global Python was installed.
pause
exit /b 2
:py
py -3 -m saq_installer.gui
goto result
:python
python -m saq_installer.gui
:result
set "SAQ_RC=%ERRORLEVEL%"
if not "%SAQ_RC%"=="0" pause
exit /b %SAQ_RC%
